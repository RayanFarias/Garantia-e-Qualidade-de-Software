"""FT06 (Trancamento) - CT021 a CT023; FT07 (Histórico/CR) - CT024, CT025; FT08 (Relatório) - CT026;
Cenário de sistema - CT027; Regressão - CT028."""
import pytest

from academico import NaoEncontradoError, RegraNegocioError
from helpers import concluir, novo_aluno

SEM = "2026.2"


@pytest.mark.ct("CT021")
def test_ct021_trancar_matricula_em_andamento(sistema, matricula):
    a = matricula.matricula
    m = sistema.trancar_matricula(a, "QS101", SEM)
    assert m.status == "TRANCADA"
    assert sistema.situacao(a, "QS101", SEM) == "TRANCADA"
    with pytest.raises(RegraNegocioError):          # matrícula trancada não recebe notas
        sistema.lancar_nota(a, "QS101", SEM, "N1", 8)
    with pytest.raises(RegraNegocioError):          # e não pode ser trancada de novo
        sistema.trancar_matricula(a, "QS101", SEM)


@pytest.mark.ct("CT022")
def test_ct022_trancamento_libera_vaga(sistema):
    sistema.cadastrar_disciplina("QS101", "Qualidade", 60, 1)
    a1, a2 = novo_aluno(sistema, 1), novo_aluno(sistema, 2)
    sistema.matricular(a1.matricula, "QS101", SEM)
    with pytest.raises(RegraNegocioError):          # turma cheia
        sistema.matricular(a2.matricula, "QS101", SEM)
    sistema.trancar_matricula(a1.matricula, "QS101", SEM)
    sistema.matricular(a2.matricula, "QS101", SEM)  # vaga liberada
    assert sistema.relatorio_disciplina("QS101", SEM)["total_alunos"] == 1


@pytest.mark.ct("CT022")
def test_ct022_trancamento_libera_limite_de_disciplinas_do_aluno(sistema, aluno):
    for i in range(1, 8):
        sistema.cadastrar_disciplina(f"D{i:03d}", f"Disciplina {i}", 60, 30)
    for i in range(1, 7):
        sistema.matricular(aluno.matricula, f"D{i:03d}", SEM)
    sistema.trancar_matricula(aluno.matricula, "D006", SEM)
    sistema.matricular(aluno.matricula, "D007", SEM)   # volta a ter 6 ativas


@pytest.mark.ct("CT023")
def test_ct023_impedir_trancar_disciplina_concluida(sistema, matricula):
    concluir(sistema, matricula, "QS101", SEM, 9, 9)   # aprovado
    with pytest.raises(RegraNegocioError):
        sistema.trancar_matricula(matricula.matricula, "QS101", SEM)


@pytest.mark.ct("CT023")
def test_ct023_trancar_matricula_inexistente(sistema, aluno, disciplina):
    with pytest.raises(NaoEncontradoError):
        sistema.trancar_matricula(aluno.matricula, "QS101", SEM)


@pytest.mark.ct("CT024")
def test_ct024_historico_escolar(sistema, aluno):
    sistema.cadastrar_disciplina("MAT101", "Matemática", 60, 30)
    sistema.cadastrar_disciplina("PRG101", "Programação", 80, 30)
    concluir(sistema, aluno, "PRG101", "2026.1", 8, 9, aulas=40, faltas=4)
    concluir(sistema, aluno, "MAT101", "2026.1", 2, 3)
    sistema.matricular(aluno.matricula, "MAT101", "2026.2")
    h = sistema.historico(aluno.matricula)
    assert [(l["semestre"], l["codigo"], l["situacao"]) for l in h] == [
        ("2026.1", "MAT101", "REPROVADO_POR_NOTA"),
        ("2026.1", "PRG101", "APROVADO"),
        ("2026.2", "MAT101", "EM_ANDAMENTO"),
    ]
    assert h[1]["media_final"] == pytest.approx(8.5)
    assert h[1]["frequencia"] == pytest.approx(90.0)


@pytest.mark.ct("CT025")
def test_ct025_coeficiente_de_rendimento_ponderado(sistema, aluno):
    sistema.cadastrar_disciplina("MAT101", "Matemática", 40, 30)     # CH 40, média 9
    sistema.cadastrar_disciplina("PRG101", "Programação", 80, 30)    # CH 80, média 6
    concluir(sistema, aluno, "MAT101", "2026.1", 9, 9)
    concluir(sistema, aluno, "PRG101", "2026.1", 6, 6, final=None)   # em exame final: não entra
    assert sistema.coeficiente_rendimento(aluno.matricula) == pytest.approx(9.0)
    sistema.lancar_nota(aluno.matricula, "PRG101", "2026.1", "FINAL", 6)   # média final 6,0
    # ponderado: (9*40 + 6*80) / 120 = 7,0   (média simples seria 7,5)
    assert sistema.coeficiente_rendimento(aluno.matricula) == pytest.approx(7.0)


@pytest.mark.ct("CT025")
def test_ct025_cr_sem_disciplinas_concluidas_e_zero(sistema, matricula):
    assert sistema.coeficiente_rendimento(matricula.matricula) == 0.0


@pytest.mark.ct("CT026")
def test_ct026_relatorio_da_disciplina(sistema, disciplina):
    alunos = [novo_aluno(sistema, n) for n in range(1, 5)]
    concluir(sistema, alunos[0], "QS101", SEM, 9, 9)               # aprovado, 9,0
    concluir(sistema, alunos[1], "QS101", SEM, 7, 7)               # aprovado, 7,0
    concluir(sistema, alunos[2], "QS101", SEM, 2, 2)               # reprovado, 2,0
    sistema.matricular(alunos[3].matricula, "QS101", SEM)          # em andamento
    r = sistema.relatorio_disciplina("QS101", SEM)
    assert r["total_alunos"] == 4
    assert r["aprovados"] == 2
    assert r["taxa_aprovacao"] == pytest.approx(66.67)
    assert r["media_turma"] == pytest.approx(6.0)                  # (9+7+2)/3
    assert {a["situacao"] for a in r["alunos"]} == {"APROVADO", "REPROVADO_POR_NOTA", "EM_ANDAMENTO"}


@pytest.mark.ct("CT027")
def test_ct027_fluxo_completo_do_semestre(sistema):
    """Cenário ponta a ponta: cadastro -> matrícula -> avaliações -> situação -> histórico/CR."""
    sistema.cadastrar_disciplina("MAT101", "Matemática", 60, 2)
    sistema.cadastrar_disciplina("MAT201", "Cálculo", 60, 2, ("MAT101",))
    ana = sistema.cadastrar_aluno("Ana Souza", "529.982.247-25", "ana@exemplo.com")
    bia = sistema.cadastrar_aluno("Bia Lima", "111.444.777-35", "bia@exemplo.com")

    concluir(sistema, ana, "MAT101", "2026.1", 8, 8)
    concluir(sistema, bia, "MAT101", "2026.1", 5, 5, final=7)       # (5+7)/2 = 6 -> aprovada
    assert sistema.situacao(bia.matricula, "MAT101", "2026.1") == "APROVADO"

    sistema.matricular(ana.matricula, "MAT201", "2026.2")
    sistema.matricular(bia.matricula, "MAT201", "2026.2")
    concluir(sistema, ana, "MAT201", "2026.2", 10, 10)
    concluir(sistema, bia, "MAT201", "2026.2", 10, 10, aulas=40, faltas=20)   # 50% -> reprovada por falta

    assert sistema.situacao(ana.matricula, "MAT201", "2026.2") == "APROVADO"
    assert sistema.situacao(bia.matricula, "MAT201", "2026.2") == "REPROVADO_POR_FALTA"
    assert sistema.coeficiente_rendimento(ana.matricula) == pytest.approx(9.0)
    assert sistema.coeficiente_rendimento(bia.matricula) == pytest.approx(8.0)  # (6+10)/2, mesma CH
    assert len(sistema.historico(ana.matricula)) == 2


@pytest.mark.ct("CT028")
def test_ct028_regressao_trancamento_nao_afeta_outras_matriculas(sistema, aluno):
    """Após alterar o trancamento, histórico/CR/relatório das demais disciplinas permanecem corretos."""
    sistema.cadastrar_disciplina("MAT101", "Matemática", 60, 30)
    sistema.cadastrar_disciplina("PRG101", "Programação", 60, 30)
    concluir(sistema, aluno, "MAT101", SEM, 8, 8)
    sistema.matricular(aluno.matricula, "PRG101", SEM)
    sistema.trancar_matricula(aluno.matricula, "PRG101", SEM)
    h = {l["codigo"]: l["situacao"] for l in sistema.historico(aluno.matricula)}
    assert h == {"MAT101": "APROVADO", "PRG101": "TRANCADA"}
    assert sistema.coeficiente_rendimento(aluno.matricula) == pytest.approx(8.0)
    assert sistema.relatorio_disciplina("PRG101", SEM)["total_alunos"] == 0
    sistema.matricular(aluno.matricula, "PRG101", SEM)               # rematrícula após trancar
    assert sistema.situacao(aluno.matricula, "PRG101", SEM) == "EM_ANDAMENTO"
