"""FT04 (Notas e frequência) - CT012 a CT015 e FT05 (Situação final) - CT016 a CT020."""
import pytest

from academico import RegraNegocioError, ValidacaoError
from helpers import concluir

SEM = "2026.2"


# ----------------------------------------------------------------- FT04
@pytest.mark.ct("CT012")
def test_ct012_lancar_notas_e_calcular_media(sistema, matricula):
    a = matricula.matricula
    assert sistema.media_parcial(a, "QS101", SEM) is None   # sem notas ainda
    sistema.lancar_nota(a, "QS101", SEM, "N1", 6.5)
    assert sistema.media_parcial(a, "QS101", SEM) is None   # falta N2
    sistema.lancar_nota(a, "QS101", SEM, "N2", 8.0)
    assert sistema.media_parcial(a, "QS101", SEM) == pytest.approx(7.25)


@pytest.mark.ct("CT013")
@pytest.mark.parametrize("valor", [-0.1, -1, 10.1, 11, 100, "8", None, True])
def test_ct013_rejeitar_notas_invalidas(sistema, matricula, valor):
    with pytest.raises(ValidacaoError):
        sistema.lancar_nota(matricula.matricula, "QS101", SEM, "N1", valor)


@pytest.mark.ct("CT013")
@pytest.mark.parametrize("valor", [0, 0.0, 0.1, 9.9, 10, 10.0])
def test_ct013_aceitar_notas_nos_limites(sistema, matricula, valor):
    sistema.lancar_nota(matricula.matricula, "QS101", SEM, "N1", valor)
    assert sistema.obter_matricula(matricula.matricula, "QS101", SEM).n1 == valor


@pytest.mark.ct("CT014")
def test_ct014_registrar_frequencia_e_calcular_percentual(sistema, matricula):
    a = matricula.matricula
    assert sistema.frequencia(a, "QS101", SEM) is None
    sistema.registrar_frequencia(a, "QS101", SEM, 40, 10)
    assert sistema.frequencia(a, "QS101", SEM) == pytest.approx(75.0)
    sistema.registrar_frequencia(a, "QS101", SEM, 40, 0)
    assert sistema.frequencia(a, "QS101", SEM) == pytest.approx(100.0)


@pytest.mark.ct("CT015")
@pytest.mark.parametrize("aulas,faltas", [(40, 41), (40, -1), (0, 0), (-5, 0), (40, 2.5), (40, "3")])
def test_ct015_rejeitar_frequencia_invalida(sistema, matricula, aulas, faltas):
    with pytest.raises(ValidacaoError):
        sistema.registrar_frequencia(matricula.matricula, "QS101", SEM, aulas, faltas)


@pytest.mark.ct("CT015")
def test_ct015_faltas_igual_a_aulas_e_valido(sistema, matricula):
    sistema.registrar_frequencia(matricula.matricula, "QS101", SEM, 40, 40)
    assert sistema.frequencia(matricula.matricula, "QS101", SEM) == 0.0


# ----------------------------------------------------------------- FT05
@pytest.mark.ct("CT016")
@pytest.mark.parametrize("n1,n2,esperado", [
    (7, 7, "APROVADO"),               # limite exato: média 7,0
    (6.9, 7.1, "APROVADO"),           # média 7,0 com decimais
    (7.5, 6.5, "APROVADO"),
    (10, 10, "APROVADO"),
    (6.5, 7.0, "EM_EXAME_FINAL"),     # média 6,75 (logo abaixo do limite)
])
def test_ct016_aprovacao_direta_valor_limite(sistema, matricula, n1, n2, esperado):
    concluir(sistema, matricula, "QS101", SEM, n1, n2, aulas=40, faltas=0)
    assert sistema.situacao(matricula.matricula, "QS101", SEM) == esperado


@pytest.mark.ct("CT017")
@pytest.mark.parametrize("faltas,esperado", [
    (0, "APROVADO"),
    (10, "APROVADO"),              # 75,0% de frequência (limite exato) -> aprovado
    (11, "REPROVADO_POR_FALTA"),   # 72,5% -> reprovado mesmo com nota 10
    (40, "REPROVADO_POR_FALTA"),
])
def test_ct017_reprovacao_por_falta_valor_limite(sistema, matricula, faltas, esperado):
    concluir(sistema, matricula, "QS101", SEM, 10, 10, aulas=40, faltas=faltas)
    assert sistema.situacao(matricula.matricula, "QS101", SEM) == esperado


@pytest.mark.ct("CT018")
@pytest.mark.parametrize("n1,n2,esperado", [
    (0, 0, "REPROVADO_POR_NOTA"),
    (3.9, 3.9, "REPROVADO_POR_NOTA"),   # média 3,9
    (4, 4, "EM_EXAME_FINAL"),           # média 4,0 (limite) -> exame final
])
def test_ct018_reprovacao_por_nota_valor_limite(sistema, matricula, n1, n2, esperado):
    concluir(sistema, matricula, "QS101", SEM, n1, n2)
    assert sistema.situacao(matricula.matricula, "QS101", SEM) == esperado


@pytest.mark.ct("CT019")
@pytest.mark.parametrize("n1,n2,final,esperado,media_final", [
    (5, 5, 5, "APROVADO", 5.0),            # (5+5)/2 = 5,0  (limite)
    (4, 4, 6, "APROVADO", 5.0),            # (4+6)/2 = 5,0  (limite)
    (4, 5, 5, "REPROVADO_POR_NOTA", 4.75),  # média 4,5 ; (4,5+5)/2 = 4,75
    (6, 6.8, 3, "REPROVADO_POR_NOTA", 4.7),
    (6, 6.8, 10, "APROVADO", 8.2),
])
def test_ct019_exame_final_tabela_de_decisao(sistema, matricula, n1, n2, final, esperado, media_final):
    a = matricula.matricula
    concluir(sistema, matricula, "QS101", SEM, n1, n2)
    assert sistema.situacao(a, "QS101", SEM) == "EM_EXAME_FINAL"
    sistema.lancar_nota(a, "QS101", SEM, "FINAL", final)
    assert sistema.situacao(a, "QS101", SEM) == esperado
    assert sistema.media_final(a, "QS101", SEM) == pytest.approx(media_final)


@pytest.mark.ct("CT020")
def test_ct020_impedir_nota_final_fora_do_exame(sistema, matricula):
    a = matricula.matricula
    with pytest.raises(RegraNegocioError):                       # ainda sem notas
        sistema.lancar_nota(a, "QS101", SEM, "FINAL", 8)
    concluir(sistema, matricula, "QS101", SEM, 9, 9)             # aprovado direto
    with pytest.raises(RegraNegocioError):
        sistema.lancar_nota(a, "QS101", SEM, "FINAL", 8)
