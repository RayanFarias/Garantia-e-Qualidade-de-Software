"""FT03 (Matrícula) - CT007 a CT011."""
import pytest

from academico import RegraNegocioError, NaoEncontradoError
from helpers import concluir, novo_aluno

SEM = "2026.2"


@pytest.mark.ct("CT007")
def test_ct007_matricular_aluno_com_vaga(sistema, aluno, disciplina):
    m = sistema.matricular(aluno.matricula, "QS101", SEM)
    assert (m.aluno, m.codigo, m.semestre, m.status) == (aluno.matricula, "QS101", SEM, "CURSANDO")
    assert sistema.situacao(aluno.matricula, "QS101", SEM) == "EM_ANDAMENTO"


@pytest.mark.ct("CT007")
def test_ct007_matricula_de_entidades_inexistentes(sistema, aluno, disciplina):
    with pytest.raises(NaoEncontradoError):
        sistema.matricular("99999999", "QS101", SEM)
    with pytest.raises(NaoEncontradoError):
        sistema.matricular(aluno.matricula, "ZZZ999", SEM)


@pytest.mark.ct("CT008")
def test_ct008_bloquear_matricula_duplicada(sistema, matricula):
    with pytest.raises(RegraNegocioError):
        sistema.matricular(matricula.matricula, "QS101", SEM)


@pytest.mark.ct("CT008")
def test_ct008_bloquear_rematricula_em_disciplina_aprovada(sistema, matricula):
    concluir(sistema, matricula, "QS101", SEM, 8, 9)
    with pytest.raises(RegraNegocioError):
        sistema.matricular(matricula.matricula, "QS101", "2027.1")


@pytest.mark.ct("CT009")
def test_ct009_bloquear_matricula_com_vagas_esgotadas(sistema):
    sistema.cadastrar_disciplina("QS101", "Qualidade", 60, 2)
    a1, a2, a3 = (novo_aluno(sistema, n) for n in (1, 2, 3))
    sistema.matricular(a1.matricula, "QS101", SEM)
    sistema.matricular(a2.matricula, "QS101", SEM)      # ocupa a última vaga (limite)
    with pytest.raises(RegraNegocioError):
        sistema.matricular(a3.matricula, "QS101", SEM)  # vaga N+1 deve ser negada


@pytest.mark.ct("CT010")
def test_ct010_exigir_todos_os_prerequisitos(sistema, aluno):
    sistema.cadastrar_disciplina("MAT101", "Matemática", 60, 30)
    sistema.cadastrar_disciplina("PRG101", "Programação", 60, 30)
    sistema.cadastrar_disciplina("ED201", "Estruturas de Dados", 60, 30, ("MAT101", "PRG101"))

    with pytest.raises(RegraNegocioError):          # nenhum cumprido
        sistema.matricular(aluno.matricula, "ED201", "2026.2")

    concluir(sistema, aluno, "MAT101", "2026.1", 9, 9)
    with pytest.raises(RegraNegocioError):          # apenas um dos dois cumprido
        sistema.matricular(aluno.matricula, "ED201", "2026.2")

    concluir(sistema, aluno, "PRG101", "2026.1", 8, 8)
    assert sistema.matricular(aluno.matricula, "ED201", "2026.2").codigo == "ED201"  # ambos


@pytest.mark.ct("CT010")
def test_ct010_prerequisito_reprovado_nao_conta(sistema, aluno):
    sistema.cadastrar_disciplina("MAT101", "Matemática", 60, 30)
    sistema.cadastrar_disciplina("MAT201", "Cálculo", 60, 30, ("MAT101",))
    concluir(sistema, aluno, "MAT101", "2026.1", 3, 3)   # reprovado por nota
    with pytest.raises(RegraNegocioError):
        sistema.matricular(aluno.matricula, "MAT201", "2026.2")


@pytest.mark.ct("CT011")
def test_ct011_limite_de_seis_disciplinas_por_semestre(sistema, aluno):
    for i in range(1, 8):
        sistema.cadastrar_disciplina(f"D{i:03d}", f"Disciplina {i}", 60, 30)
    for i in range(1, 7):                                # 6ª matrícula ainda é permitida
        sistema.matricular(aluno.matricula, f"D{i:03d}", SEM)
    with pytest.raises(RegraNegocioError):               # 7ª deve ser negada
        sistema.matricular(aluno.matricula, "D007", SEM)
    sistema.matricular(aluno.matricula, "D007", "2027.1")  # outro semestre não é afetado
