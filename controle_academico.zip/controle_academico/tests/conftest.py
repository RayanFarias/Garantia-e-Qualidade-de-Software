import pytest

from academico import SistemaAcademico
from helpers import novo_aluno

SEM = "2026.2"


@pytest.fixture
def sistema():
    """Sistema vazio para cada teste (isolamento)."""
    return SistemaAcademico()


@pytest.fixture
def aluno(sistema):
    return novo_aluno(sistema, 1, "Maria da Silva")


@pytest.fixture
def disciplina(sistema):
    return sistema.cadastrar_disciplina("QS101", "Garantia de Qualidade de Software", 60, 40)


@pytest.fixture
def matricula(sistema, aluno, disciplina):
    """Aluno já matriculado em QS101 no semestre 2026.2."""
    sistema.matricular(aluno.matricula, "QS101", SEM)
    return aluno
