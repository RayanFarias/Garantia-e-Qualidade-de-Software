"""Funções auxiliares compartilhadas pelos testes."""


def gerar_cpf(base9: str) -> str:
    """Gera um CPF válido (com dígitos verificadores) a partir de 9 dígitos."""
    d = [int(c) for c in base9]
    for tamanho in (9, 10):
        soma = sum(d[i] * (tamanho + 1 - i) for i in range(tamanho))
        d.append(soma * 10 % 11 % 10)
    return "".join(map(str, d))


def novo_aluno(sistema, n: int = 1, nome: str = None):
    """Cadastra um aluno com CPF único e válido (n diferencia os alunos)."""
    base = f"{n:09d}"
    if len(set(base)) == 1:           # evita CPF com dígitos repetidos
        base = f"1{n:08d}"
    return sistema.cadastrar_aluno(nome or f"Aluno Teste {n}", gerar_cpf(base),
                                   f"aluno{n}@exemplo.com")


def concluir(sistema, aluno, codigo, semestre, n1, n2, aulas=40, faltas=0, final=None):
    """Matricula (se necessário), lança notas/frequência e, se informado, o exame final."""
    try:
        sistema.obter_matricula(aluno.matricula, codigo, semestre)
    except Exception:
        sistema.matricular(aluno.matricula, codigo, semestre)
    sistema.lancar_nota(aluno.matricula, codigo, semestre, "N1", n1)
    sistema.lancar_nota(aluno.matricula, codigo, semestre, "N2", n2)
    sistema.registrar_frequencia(aluno.matricula, codigo, semestre, aulas, faltas)
    if final is not None:
        sistema.lancar_nota(aluno.matricula, codigo, semestre, "FINAL", final)
