"""FT01 (Cadastro de alunos) e FT02 (Cadastro de disciplinas) - CT001 a CT006."""
import pytest

from academico import NaoEncontradoError, RegraNegocioError, ValidacaoError
from helpers import gerar_cpf, novo_aluno


@pytest.mark.ct("CT001")
def test_ct001_cadastrar_aluno_valido(sistema):
    a = sistema.cadastrar_aluno("João Pereira", "529.982.247-25", "joao@exemplo.com")
    assert a.matricula == "20260001"
    assert a.cpf == "52998224725"
    assert sistema.obter_aluno("20260001").nome == "João Pereira"
    b = novo_aluno(sistema, 2)
    assert b.matricula == "20260002"  # matrícula sequencial e única


@pytest.mark.ct("CT002")
@pytest.mark.parametrize("cpf", ["123.456.789-00", "111.111.111-11", "1234", "", "abcdefghijk",
                                 "529.982.247-24"])
def test_ct002_rejeitar_cpf_invalido(sistema, cpf):
    with pytest.raises(ValidacaoError):
        sistema.cadastrar_aluno("João Pereira", cpf, "joao@exemplo.com")


@pytest.mark.ct("CT003")
def test_ct003_rejeitar_cpf_duplicado(sistema):
    sistema.cadastrar_aluno("João Pereira", "529.982.247-25", "joao@exemplo.com")
    with pytest.raises(RegraNegocioError):
        sistema.cadastrar_aluno("Outro Aluno", "52998224725", "outro@exemplo.com")


@pytest.mark.ct("CT004")
@pytest.mark.parametrize("email", ["semarroba.com", "a@", "@b.com", "a b@c.com", "a@b", ""])
def test_ct004_rejeitar_email_invalido(sistema, email):
    with pytest.raises(ValidacaoError):
        sistema.cadastrar_aluno("João Pereira", "529.982.247-25", email)


@pytest.mark.ct("CT005")
def test_ct005_cadastrar_disciplina_valida(sistema):
    sistema.cadastrar_disciplina("mat101", "Matemática", 60, 30)
    d = sistema.cadastrar_disciplina("MAT201", "Cálculo", 80, 25, pre_requisitos=("mat101",))
    assert d.codigo == "MAT201"
    assert d.pre_requisitos == ("MAT101",)
    assert sistema.obter_disciplina("mat101").carga_horaria == 60
    with pytest.raises(RegraNegocioError):
        sistema.cadastrar_disciplina("MAT101", "Duplicada", 60, 30)
    with pytest.raises(NaoEncontradoError):
        sistema.cadastrar_disciplina("FIS101", "Física", 60, 30, pre_requisitos=("XXX999",))


@pytest.mark.ct("CT006")
@pytest.mark.parametrize("carga,vagas", [(0, 10), (-60, 10), (60, 0), (60, -1), (60.5, 10), ("60", 10)])
def test_ct006_rejeitar_carga_horaria_ou_vagas_invalidas(sistema, carga, vagas):
    with pytest.raises(ValidacaoError):
        sistema.cadastrar_disciplina("QS101", "Qualidade", carga, vagas)


@pytest.mark.ct("CT006")
def test_ct006_limite_inferior_valido(sistema):
    d = sistema.cadastrar_disciplina("QS101", "Qualidade", 1, 1)  # menor valor válido
    assert (d.carga_horaria, d.vagas) == (1, 1)


@pytest.mark.ct("CT001")
def test_ct001_massa_de_dados_gerador_de_cpf_produz_cpf_valido():
    """Valida a massa de dados: o gerador de CPF usado pelos demais testes gera CPFs válidos."""
    from academico.validators import cpf_valido
    assert gerar_cpf("529982247") == "52998224725"
    assert cpf_valido(gerar_cpf("111444777"))
