"""Demonstração em linha de comando do Sistema de Controle Acadêmico (python main.py)."""
import sys
sys.path.insert(0, "src")

from academico import SistemaAcademico  # noqa: E402


def main():
    s = SistemaAcademico()
    s.cadastrar_disciplina("MAT101", "Matemática", 60, 30)
    s.cadastrar_disciplina("PRG101", "Programação", 80, 30)
    ana = s.cadastrar_aluno("Ana Souza", "529.982.247-25", "ana@exemplo.com")

    for cod, n1, n2, faltas in (("MAT101", 9, 9, 0), ("PRG101", 5, 6, 4)):
        s.matricular(ana.matricula, cod, "2026.1")
        s.lancar_nota(ana.matricula, cod, "2026.1", "N1", n1)
        s.lancar_nota(ana.matricula, cod, "2026.1", "N2", n2)
        s.registrar_frequencia(ana.matricula, cod, "2026.1", 40, faltas)
    s.lancar_nota(ana.matricula, "PRG101", "2026.1", "FINAL", 7)

    print(f"Histórico de {ana.nome} ({ana.matricula})")
    for l in s.historico(ana.matricula):
        print(f"  {l['semestre']} {l['codigo']} {l['disciplina']:<12} média {l['media_final']:>4} "
              f"freq {l['frequencia']:>5}%  {l['situacao']}")
    print("CR:", s.coeficiente_rendimento(ana.matricula))


if __name__ == "__main__":
    main()
