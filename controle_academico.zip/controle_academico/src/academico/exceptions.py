"""Exceções do domínio acadêmico."""


class ErroAcademico(Exception):
    """Classe base para todos os erros do sistema."""


class ValidacaoError(ErroAcademico):
    """Dado de entrada inválido (formato, faixa, tipo)."""


class RegraNegocioError(ErroAcademico):
    """Operação viola uma regra de negócio (RNxx)."""


class NaoEncontradoError(ErroAcademico):
    """Entidade (aluno, disciplina, matrícula) inexistente."""
