"""Entidades do domínio."""
from dataclasses import dataclass, field
from typing import Optional, Tuple

from .regras import STATUS_CURSANDO


@dataclass
class Aluno:
    matricula: str
    nome: str
    cpf: str
    email: str


@dataclass
class Disciplina:
    codigo: str
    nome: str
    carga_horaria: int
    vagas: int
    pre_requisitos: Tuple[str, ...] = field(default_factory=tuple)


@dataclass
class Matricula:
    aluno: str
    codigo: str
    semestre: str
    status: str = STATUS_CURSANDO
    n1: Optional[float] = None
    n2: Optional[float] = None
    final: Optional[float] = None
    aulas_dadas: int = 0
    faltas: int = 0
