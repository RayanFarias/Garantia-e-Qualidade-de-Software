"""Funções de validação de dados de entrada."""
import re

from .exceptions import ValidacaoError
from .regras import NOTA_MAX, NOTA_MIN

_EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}$")
_SEMESTRE_RE = re.compile(r"^\d{4}\.[12]$")


def somente_digitos(texto: str) -> str:
    return re.sub(r"\D", "", texto or "")


def cpf_valido(cpf: str) -> bool:
    """Valida CPF pelo tamanho e pelos dois dígitos verificadores."""
    d = somente_digitos(cpf)
    if len(d) != 11 or d == d[0] * 11:
        return False
    for tamanho in (9, 10):
        soma = sum(int(d[i]) * (tamanho + 1 - i) for i in range(tamanho))
        digito = (soma * 10) % 11 % 10
        if digito != int(d[tamanho]):
            return False
    return True


def email_valido(email: str) -> bool:
    return bool(email) and bool(_EMAIL_RE.match(email.strip()))


def semestre_valido(semestre: str) -> bool:
    return bool(semestre) and bool(_SEMESTRE_RE.match(semestre))


def validar_nota(valor) -> float:
    """Garante número entre 0 e 10 (RN09)."""
    if isinstance(valor, bool) or not isinstance(valor, (int, float)):
        raise ValidacaoError("Nota deve ser numérica.")
    if valor < NOTA_MIN or valor > NOTA_MAX:
        raise ValidacaoError("Nota deve estar entre 0 e 10.")
    return float(valor)


def validar_inteiro_positivo(valor, campo: str) -> int:
    if isinstance(valor, bool) or not isinstance(valor, int) or valor <= 0:
        raise ValidacaoError(f"{campo} deve ser um inteiro maior que zero.")
    return valor
