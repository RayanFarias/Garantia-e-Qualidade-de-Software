# -*- coding: utf-8 -*-
"""Preenche o template DOCX do professor com a especificação e os resultados dos testes.

Uso: python3 scripts/gerar_especificacao_docx.py <template.docx> <saida.docx>
Os resultados (aprovado/reprovado por ciclo) são lidos dos XMLs JUnit gerados pelo pytest em evidencias/.
"""
import copy
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

from docx import Document
from docx.oxml.ns import qn
from lxml import etree

sys.path.insert(0, str(Path(__file__).parent))
from dados_documento import *  # noqa: E402,F403

RAIZ = Path(__file__).resolve().parent.parent
XML_SPACE = "{http://www.w3.org/XML/1998/namespace}space"
VERDE, VERMELHO = "1E7B34", "C00000"


# ------------------------------------------------------------------ resultados reais do pytest
def ler_ciclo(n):
    pasta = RAIZ / CICLOS[n][2] / "resultado.xml"
    raiz = ET.parse(pasta).getroot()
    suite = raiz.find("testsuite") if raiz.tag == "testsuites" else raiz
    por_ct, total, falhas = {}, 0, 0
    for tc in suite.iter("testcase"):
        m = re.search(r"test_(ct\d{3})_", tc.attrib["name"])
        if not m:
            continue  # testes auxiliares sem CT
        ct = m.group(1).upper()
        falhou = tc.find("failure") is not None or tc.find("error") is not None
        d = por_ct.setdefault(ct, {"n": 0, "falhas": 0})
        d["n"] += 1
        d["falhas"] += falhou
        total += 1
        falhas += falhou
    return {"por_ct": por_ct, "total": total, "falhas": falhas, "timestamp": suite.attrib.get("timestamp", "")}


RES = {n: ler_ciclo(n) for n in (1, 2, 3)}
CTS = sorted(CASOS)
assert len(CTS) == 28
for n in (1, 2, 3):
    assert set(RES[n]["por_ct"]) == set(CTS), "todos os CTs devem ter testes implementados"

# confere o que foi escrito à mão (FALHAS) com o que o pytest realmente registrou
for n in (1, 2, 3):
    reais = {ct for ct, d in RES[n]["por_ct"].items() if d["falhas"]}
    escritos = {ct for ct, c in FALHAS.items() if n in c}
    assert reais == escritos, f"ciclo {n}: pytest={sorted(reais)} documento={sorted(escritos)}"


def status_ct(ct, n):
    return "Reprovado" if RES[n]["por_ct"][ct]["falhas"] else "Aprovado"


def contagem(n):
    ap = sum(status_ct(ct, n) == "Aprovado" for ct in CTS)
    return ap, len(CTS) - ap


# ------------------------------------------------------------------ utilidades de XML
def trocar_texto(par, texto, cor=None, negrito=False):
    """Substitui o texto de um <w:p> mantendo a formatação do primeiro run; '\n' vira quebra de linha."""
    runs = par.findall(qn("w:r"))
    if not runs:
        raise ValueError("parágrafo sem run para clonar formatação")
    primeiro = runs[0]
    for r in runs[1:]:
        par.remove(r)
    for filho in list(primeiro):
        if filho.tag in (qn("w:t"), qn("w:br")):
            primeiro.remove(filho)
    for i, linha in enumerate(str(texto).split("\n")):
        if i:
            etree.SubElement(primeiro, qn("w:br"))
        t = etree.SubElement(primeiro, qn("w:t"))
        t.text = linha
        t.set(XML_SPACE, "preserve")
    rpr = primeiro.find(qn("w:rPr"))
    if cor or negrito:
        if rpr is None:
            rpr = etree.Element(qn("w:rPr"))
            primeiro.insert(0, rpr)
        if negrito and rpr.find(qn("w:b")) is None:
            inserir_ordenado(rpr, etree.Element(qn("w:b")))
        if cor:
            c = rpr.find(qn("w:color"))
            if c is None:
                c = etree.Element(qn("w:color"))
                inserir_ordenado(rpr, c)
            c.set(qn("w:val"), cor)


_ORDEM_RPR = ["rStyle", "rFonts", "b", "bCs", "i", "iCs", "caps", "smallCaps", "strike", "dstrike", "outline", "shadow",
              "emboss", "imprint", "noProof", "snapToGrid", "vanish", "webHidden", "color", "spacing", "w", "kern",
              "position", "sz", "szCs", "highlight", "u", "effect", "bdr", "shd", "fitText", "vertAlign"]


def inserir_ordenado(rpr, novo):
    """Insere um filho em <w:rPr> respeitando a ordem exigida pelo schema do Word."""
    nome = etree.QName(novo).localname
    pos = _ORDEM_RPR.index(nome)
    for i, filho in enumerate(rpr):
        ln = etree.QName(filho).localname
        if ln in _ORDEM_RPR and _ORDEM_RPR.index(ln) > pos:
            rpr.insert(i, novo)
            return
    rpr.append(novo)


def celulas(tr):
    return tr.findall(qn("w:tc"))


def cel_texto(tc, texto, **kw):
    pars = tc.findall(qn("w:p"))
    for extra in pars[1:]:
        tc.remove(extra)
    trocar_texto(pars[0], texto, **kw)


def texto_de(el):
    return "".join(t.text or "" for t in el.iter(qn("w:t")))


def linhas(tbl):
    return tbl.findall(qn("w:tr"))


def colorir_status(texto):
    t = str(texto)
    if t.startswith("Aprovado") or t.startswith("Resolvido"):
        return dict(cor=VERDE, negrito=True)
    if t.startswith("Reprovado"):
        return dict(cor=VERMELHO, negrito=True)
    return {}


def preencher_tabela(tbl, dados, larguras=None, col_status=()):
    """Mantém o cabeçalho (linha 0), usa a linha 1 como protótipo e cria uma linha por item de 'dados'."""
    trs = linhas(tbl)
    proto = copy.deepcopy(trs[1])
    for tr in trs[1:]:
        tbl.remove(tr)
    for item in dados:
        tr = copy.deepcopy(proto)
        for i, (tc, valor) in enumerate(zip(celulas(tr), item)):
            kw = colorir_status(valor) if i in col_status else {}
            cel_texto(tc, valor, **kw)
        tbl.append(tr)
    if larguras:
        definir_larguras(tbl, larguras)


def definir_larguras(tbl, larguras):
    grid = tbl.find(qn("w:tblGrid"))
    for gc, w in zip(grid.findall(qn("w:gridCol")), larguras):
        gc.set(qn("w:w"), str(w))
    for tr in linhas(tbl):
        for tc, w in zip(celulas(tr), larguras):
            tcw = tc.find(qn("w:tcPr")).find(qn("w:tcW"))
            tcw.set(qn("w:w"), str(w))
            tcw.set(qn("w:type"), "dxa")


def valor_rotulo(tbl, texto, **kw):
    """Tabela chave/valor de 1 linha: escreve o valor na 2ª célula."""
    cel_texto(celulas(linhas(tbl)[0])[1], texto, **kw)


def manter_junto(tbl):
    """keepNext em todos os parágrafos (exceto os da última linha): a tabela não é partida entre páginas."""
    for tr in linhas(tbl)[:-1]:
        for par in tr.iter(qn("w:p")):
            ppr = par.find(qn("w:pPr"))
            if ppr is None:
                ppr = etree.Element(qn("w:pPr"))
                par.insert(0, ppr)
            if ppr.find(qn("w:keepNext")) is None:
                ppr.insert(0, etree.Element(qn("w:keepNext")))


def numerar(lista):
    return "\n".join(f"{i}. {p}" for i, p in enumerate(lista, 1))


# ------------------------------------------------------------------ montagem
def main(template, saida):
    doc = Document(template)
    corpo = doc.element.body
    ch = list(corpo.iterchildren())  # índices conforme a inspeção do template
    P = lambda i: ch[i]  # noqa: E731

    # ---- capa
    novo = copy.deepcopy(P(0))
    trocar_texto(novo, "SISTEMA DE CONTROLE ACADÊMICO")
    novo.find(qn("w:pPr")).find(qn("w:spacing")).set(qn("w:before"), "600")
    for sz in novo.iter(qn("w:sz")):
        sz.set(qn("w:val"), "36")
    P(1).addnext(novo)
    trocar_texto(P(4), f"Projeto A3 — Garantia da Qualidade de Software · Ferramenta: pytest · Versão do documento 1.0 · {DATA}")

    # ---- 1. identificação
    t = P(8)
    trs = linhas(t)
    valores = ["Sistema de Controle Acadêmico", "Garantia da Qualidade de Software (A3 – Teste de Software)",
               "UNIFACS", f"{R1}, {R2}, {R3}, {R4}", PROFESSOR]
    for tr, v in zip(trs[:5], valores):
        cel_texto(celulas(tr)[1], v)
    # a 6ª linha do template está vazia: reaproveita como "Versão"
    nova = copy.deepcopy(trs[0])
    cel_texto(celulas(nova)[0], "Versão / Data")
    cel_texto(celulas(nova)[1], f"Documento 1.0 — sistema v1.0.0 — {DATA}")
    t.replace(trs[5], nova)
    definir_larguras(t, [2600, 7336])

    # ---- 2.1 objetivo + mapeamento com o barema
    trocar_texto(P(11), "Este documento especifica, planeja e registra os testes do Sistema de Controle Acadêmico, "
                        "desenvolvido pela equipe para o Trabalho A3 da UC Garantia da Qualidade de Software. Ele reúne os requisitos "
                        "testáveis, a estratégia, os 28 casos de teste (CT001–CT028), os defeitos encontrados, o reteste/regressão "
                        "e o relatório final. Os casos foram automatizados com pytest e executados em três ciclos sobre três versões do sistema "
                        "(v0.1.0, v0.2.0 e v1.0.0), de modo que os defeitos iniciais fossem detectados, corrigidos e retestados ao longo do projeto.")
    mapa = copy.deepcopy(P(21))
    for tc, v in zip(celulas(linhas(mapa)[0]), ["Etapa (barema)", "Entrega", "Onde está neste documento"]):
        cel_texto(tc, v)
    preencher_tabela(mapa, [
        ("1 – 10 pts (03/11/2026)", "Especificação de testes (≥ 15 casos)", "Seções 1 a 12: 28 casos de teste especificados (seção 10) e rastreados aos requisitos (seção 9)."),
        ("2 – 10 pts (17/11/2026)", "Implementação (≥ 10 casos)", "28 casos implementados em pytest (pasta tests/); registro de execução na seção 13."),
        ("3 – 20 pts (01/12/2026)", "Apresentação final", "Seções 12, 13, 15 e 16: aprovados, reprovados, erros encontrados, requisitos implementados ou não e conclusões."),
    ], [2300, 3000, 4636])
    sp = copy.deepcopy(P(50))
    P(11).addnext(sp)  # espaço entre o parágrafo e a tabela
    sp.addnext(mapa)

    # ---- 2.2 objetivos
    objetivos = [
        "Verificar se os requisitos funcionais RF01 a RF09 foram implementados corretamente.",
        "Avaliar entradas válidas e inválidas (CPF, e-mail, notas, faltas, carga horária e vagas).",
        "Identificar falhas e comportamentos inesperados, inclusive nos valores-limite (média 7,0, frequência 75%, vaga N+1).",
        "Verificar as regras de negócio RN01 a RN17.",
        "Registrar que aspectos não funcionais (desempenho, segurança, usabilidade) estão fora do escopo desta versão.",
        "Registrar evidências (logs pytest e patches de correção) e fornecer informações para melhoria do sistema.",
    ]
    for i, txt in zip(range(13, 19), objetivos):
        trocar_texto(P(i), txt)

    # ---- 2.3 escopo
    preencher_tabela(P(21), [(a, b, c) for a, b, c in FUNCIONALIDADES], [900, 2600, 6436])
    preencher_tabela(P(23), FORA_ESCOPO, [3200, 6736])

    # ---- 3. descrição
    trocar_texto(P(26), "O Sistema de Controle Acadêmico gerencia o ciclo básico de uma instituição de ensino: cadastro de alunos e disciplinas, "
                        "matrícula por semestre (com vagas, pré-requisitos e limite de disciplinas), lançamento de notas e frequência, "
                        "apuração da situação final (aprovação direta, exame final, reprovação por nota ou por falta), trancamento de matrícula, "
                        "histórico escolar com Coeficiente de Rendimento (CR) e relatório por disciplina. É uma biblioteca Python (pacote academico) "
                        "com armazenamento em memória; um script de demonstração (main.py) exercita o fluxo completo.")
    preencher_tabela(P(28), PUBLICO, [2600, 7336])
    preencher_tabela(P(30), TECNOLOGIAS, [2600, 7336])
    preencher_tabela(P(32), REFERENCIAS, [2900, 7036])

    # ---- 5. estratégia
    preencher_tabela(P(35), NIVEIS, [1800, 1500, 6636], col_status=())
    preencher_tabela(P(37), TIPOS, [1800, 1500, 6636])

    # ---- 6. ambiente + 6.2 dados de teste
    preencher_tabela(P(40), AMBIENTE, [2600, 7336])
    h62 = copy.deepcopy(P(39))
    trocar_texto(h62, "6.2 Dados de teste")
    t62 = copy.deepcopy(P(40))
    for tc, v in zip(celulas(linhas(t62)[0]), ["Item", "Descrição"]):
        cel_texto(tc, v)
    preencher_tabela(t62, DADOS_TESTE, [2600, 7336])
    P(41).addprevious(h62)
    P(41).addprevious(t62)

    # ---- 7. requisitos
    preencher_tabela(P(42), [(c, tp, d, pr) for c, tp, d, pr, _ in REQUISITOS], [900, 1800, 5436, 1800])

    # ---- 8. técnicas + tabela de decisão
    preencher_tabela(P(45), TECNICAS, [3000, 1400, 5536])
    intro = copy.deepcopy(P(44))
    trocar_texto(intro, "Tabela de decisão da situação final do aluno (RN11 a RN14), base dos casos CT016 a CT019:")
    tdec = copy.deepcopy(P(42))
    for tc, v in zip(celulas(linhas(tdec)[0]), ["Frequência ≥ 75%", "Média parcial", "Nota do exame final", "Situação resultante"]):
        cel_texto(tc, v)
    preencher_tabela(tdec, DECISAO, [2000, 2400, 2600, 2936])
    espaco = copy.deepcopy(P(50))
    P(46).addprevious(espaco)
    P(46).addprevious(intro)
    P(46).addprevious(tdec)

    # ---- 9. matriz de rastreabilidade
    por_req = {}
    for ct, c in CASOS.items():
        req_txt = c[1]
        for r in re.findall(r"R[FN]\d{2}", req_txt):
            por_req.setdefault(r, []).append(ct)
        # intervalo "RF01–RF08" no CT027
        m = re.search(r"(RF)(\d{2})–RF(\d{2})", req_txt)
        if m:
            for k in range(int(m.group(2)), int(m.group(3)) + 1):
                por_req.setdefault(f"RF{k:02d}", []).append(ct)
        m = re.search(r"(RN)(\d{2})–RN(\d{2})", req_txt)
        if m:
            for k in range(int(m.group(2)), int(m.group(3)) + 1):
                por_req.setdefault(f"RN{k:02d}", []).append(ct)
    linhas_matriz = []
    for cod, _, _, _, uc in REQUISITOS:
        cts = sorted(set(por_req.get(cod, [])))
        assert cts, f"{cod} sem caso de teste"
        houve_falha = any(status_ct(ct, 1) == "Reprovado" for ct in cts)
        res = "Aprovado (após correção)" if houve_falha else "Aprovado"
        linhas_matriz.append((cod, uc, ", ".join(cts), res))
    preencher_tabela(P(47), linhas_matriz, [1000, 1500, 5036, 2400], col_status=(3,))

    # ---- 10. especificação dos casos (clona o bloco do CT001 do template)
    bloco_spec = [copy.deepcopy(P(i)) for i in range(49, 83)]
    ancora_spec = P(83)
    for i in range(49, 83):
        corpo.remove(P(i))
    for ct in CTS:
        nome, req, uc, prio, tipo, tec, resp, pre, entrada, passos, esperado, arq = CASOS[ct]
        falhas = FALHAS.get(ct, {})
        obtido = []
        for n in (1, 2, 3):
            rotulo = f"{CICLOS[n][0]} ({CICLOS[n][1]})"
            d = RES[n]["por_ct"][ct]
            if d["falhas"]:
                obtido.append(f"{rotulo}: Reprovado — {falhas[n]}")
            else:
                obtido.append(f"{rotulo}: Aprovado ({d['n']} {'execução' if d['n'] == 1 else 'execuções'} pytest).")
        bugs = sorted(x[0] for x in DEFEITOS if ct in re.findall(r"CT\d{3}", x[2]))
        obs = f"Teste automatizado: {ARQ[arq]}::test_{ct.lower()}_*. " + (
            f"Defeitos relacionados: {', '.join(bugs)} (todos resolvidos)." if bugs else "Nenhum defeito associado.")
        evid = [f"{ARQ[arq]}", f"{CICLOS[3][2]}/log_pytest.txt"]
        if falhas:
            evid.insert(1, f"{CICLOS[min(falhas)][2]}/log_pytest.txt")
        campos = {
            "Código": ct, "Nome do teste": nome, "Requisito relacionado": req, "Caso de uso": uc, "Prioridade": prio,
            "Tipo de teste": tipo, "Técnica utilizada": tec, "Responsável": resp, "Data prevista": DATA,
            "Pré-condições": pre, "Dados de entrada": entrada, "Passos para execução": numerar(passos),
            "Resultado esperado": esperado, "Resultado obtido": "\n".join(obtido),
            "Status": "Aprovado", "Evidência": "\n".join(evid), "Observações": obs,
        }
        for el in bloco_spec:
            novo = copy.deepcopy(el)
            if novo.tag == qn("w:tbl"):
                rot = texto_de(celulas(linhas(novo)[0])[0]).strip()
                valor_rotulo(novo, campos[rot], **(colorir_status(campos[rot]) if rot == "Status" else {}))
                definir_larguras(novo, [2400, 7536])
            ancora_spec.addprevious(novo)

    # ---- 11. lista de casos
    lista = [(ct, CASOS[ct][0], CASOS[ct][1], CASOS[ct][4], CASOS[ct][3], status_ct(ct, 3)) for ct in CTS]
    preencher_tabela(P(84), lista, [800, 4200, 1500, 1100, 1100, 1236], col_status=(5,))

    # ---- 12. registro de defeitos + detalhamento
    reg = [(b[0], b[1], b[2], "Resolvido") for b in DEFEITOS]
    preencher_tabela(P(86), reg, [900, 5036, 2000, 2000], col_status=(3,))
    bloco_def = [copy.deepcopy(P(i)) for i in range(88, 124)]
    ancora_def = P(124)
    for i in range(88, 124):
        corpo.remove(P(i))
    for (cod, tit, cts, req, sev, prio, resp_id, resp_corr, ciclo_id, passos, esp, obt, causa, rodada) in DEFEITOS:
        if rodada == 1:
            patch = "evidencias/correcoes_rodada1_v0.1.0_para_v0.2.0.patch"
        else:
            patch = "evidencias/correcoes_rodada2_v0.2.0_para_v1.0.0.patch"
        retest_ciclo = rodada + 1
        resultado_retest = (f"{causa}\nReteste no {CICLOS[retest_ciclo][0]} ({CICLOS[retest_ciclo][1]}): "
                            f"{re.findall(r'CT\d{3}', cts)[0]} Aprovado. Regressão: suíte completa (83 execuções) sem novas falhas "
                            f"nas demais funcionalidades afetadas." if cod != "BUG009" else
                            f"{causa}\nReteste no {CICLOS[3][0]} ({CICLOS[3][1]}): CT022 Aprovado; suíte completa (83 execuções) sem falhas.")
        campos = {
            "Código do defeito": cod, "Título": tit, "Caso de teste relacionado": cts, "Requisito relacionado": req,
            "Data de identificação": DATA, "Responsável pela identificação": resp_id,
            "Ambiente": f"Linux, Python 3.13.18, pytest 9.1.1; sistema {CICLOS[ciclo_id][1]}",
            "Pré-condições": "Sistema acadêmico vazio (fixture 'sistema' do pytest).",
            "Passos para reproduzir": numerar(passos), "Resultado esperado": esp, "Resultado obtido": obt,
            "Evidência": f"{CICLOS[ciclo_id][2]}/log_pytest.txt; correção em {patch}",
            "Severidade": sev, "Prioridade de correção": prio, "Status": "Resolvido",
            "Responsável pela correção": resp_corr, "Data da correção": DATA, "Resultado do reteste": resultado_retest,
        }
        for el in bloco_def:
            novo = copy.deepcopy(el)
            if novo.tag == qn("w:tbl"):
                rot = texto_de(celulas(linhas(novo)[0])[0]).strip()
                valor_rotulo(novo, campos[rot], **(colorir_status(campos[rot]) if rot == "Status" else {}))
                definir_larguras(novo, [2400, 7536])
            ancora_def.addprevious(novo)

    # ---- 13.1 registro de execução (resultado final + histórico de ciclos)
    exec_rows = []
    for ct in CTS:
        c = CASOS[ct]
        hist = " → ".join(f"C{n}: {status_ct(ct, n)}" for n in (1, 2, 3))
        ev = f"{CICLOS[3][2].split('/')[1]}"
        exec_rows.append((ct, DATA, c[6], c[10], hist, "Aprovado", ev + (f"\n{CICLOS[min(FALHAS[ct])][2].split('/')[1]}" if ct in FALHAS else "")))
    preencher_tabela(P(126), exec_rows, [700, 1050, 1250, 2700, 1850, 950, 1436], col_status=(5,))

    # ---- 13.2 reteste
    ret = []
    for (cod, tit, cts, req, sev, prio, ri, rc, ciclo_id, *_resto, rodada) in DEFEITOS:
        ct1 = re.findall(r"CT\d{3}", cts)[0]
        ret_ciclo = rodada + 1
        if cod == "BUG009":
            ret.append((cod, ct1, f"{DATA} (Ciclo 3)", "Vaga/limite liberados após o trancamento; suíte completa aprovada.", "Aprovado"))
            continue
        if rodada == 2:  # corrigido só na rodada 2 -> reteste do ciclo 2 reprovou
            ret.append((cod, ct1, f"{DATA} (Ciclo 2)", "Defeito ainda presente na v0.2.0 (correção prevista para a rodada 2).", "Reprovado"))
            ret.append((cod, ct1, f"{DATA} (Ciclo 3)", "Comportamento correto na v1.0.0.", "Aprovado"))
        else:
            ret.append((cod, ct1, f"{DATA} (Ciclo 2)", "Comportamento correto na v0.2.0.", "Aprovado"))
    preencher_tabela(P(128), ret, [900, 1000, 2000, 4136, 1900], col_status=(4,))

    # ---- 13.3 regressão
    todos = "CT001 a CT028"
    preencher_tabela(P(130), [
        ("Rodada 1 (v0.1.0 → v0.2.0): correção de BUG001, BUG002, BUG003, BUG004 e BUG007; implementação do trancamento (BUG008).",
         "Situação final (FT05), validação de notas (FT04), matrícula/vagas (FT03), cadastro de alunos (FT01), trancamento, histórico e relatório (FT06–FT08).",
         f"Suíte completa reexecutada no Ciclo 2 (83 execuções): {todos}."),
        ("Rodada 2 (v0.2.0 → v1.0.0): correção de BUG005, BUG006 e BUG009.",
         "Matrícula/pré-requisitos (FT03), CR/histórico (FT07), trancamento e liberação de vaga (FT06).",
         f"Suíte completa reexecutada no Ciclo 3 (83 execuções): {todos}. Destaque: CT007–CT011, CT021–CT028."),
    ], [3600, 3300, 3036])

    # ---- 14. critérios
    entrada = ["Requisitos RF01–RF09 e RN01–RN17 definidos (seção 7) e compreendidos pela equipe.",
               "Versão executável do sistema disponível (pacote academico, versão v0.1.0 para o primeiro ciclo).",
               "Ambiente configurado: Python 3.13 e pytest 9.1.1.",
               "Dados de teste preparados (seção 6.2), com isolamento por fixture.",
               "Casos de teste documentados (28 casos, seção 10) — acima do mínimo de 15 exigido."]
    saida_c = [f"Todos os casos prioritários executados: 28/28 executados, 83 execuções pytest.",
               "Defeitos principais corrigidos: 9 de 9 defeitos resolvidos (BUG001–BUG009).",
               "Casos reprovados retestados: todos os 12 casos reprovados no Ciclo 1 foram retestados e aprovados no Ciclo 3.",
               "Resultados e evidências documentados em evidencias/ (logs, XML JUnit e patches).",
               "Conclusão sobre a qualidade do sistema elaborada na seção 16.4."]
    for i, txt in zip(range(133, 138), entrada):
        trocar_texto(P(i), txt)
    for i, txt in zip(range(139, 144), saida_c):
        trocar_texto(P(i), txt)

    # ---- 15. indicadores
    ap3, rp3 = contagem(3)
    ind = [("Casos planejados", 28), ("Casos executados", 28), ("Casos aprovados", ap3), ("Casos reprovados", rp3),
           ("Casos bloqueados", 0), ("Casos não executados", 0), ("Defeitos identificados", len(DEFEITOS)),
           ("Defeitos corrigidos", len(DEFEITOS)), ("Defeitos pendentes", 0)]
    preencher_tabela(P(145), [(a, str(b)) for a, b in ind], [5200, 4736])
    trocar_texto(P(146), "Percentual de aprovação (resultado final, Ciclo 3):")
    trocar_texto(P(147), f"Percentual de aprovação = (Casos aprovados ÷ Casos executados) × 100 = ({ap3} ÷ 28) × 100 = {ap3 / 28 * 100:.0f}%")
    p_evo = copy.deepcopy(P(146))
    trocar_texto(p_evo, "Evolução por ciclo de teste:")
    evo = copy.deepcopy(P(126))
    for tc, v in zip(celulas(linhas(evo)[0]), ["Ciclo", "Versão", "Casos executados", "Casos aprovados", "Casos reprovados", "% aprovação", "Execuções pytest (aprov./reprov.)"]):
        cel_texto(tc, v)
    evo_rows = []
    for n in (1, 2, 3):
        a, r = contagem(n)
        tot, fal = RES[n]["total"], RES[n]["falhas"]
        evo_rows.append((CICLOS[n][0], CICLOS[n][1], "28", str(a), str(r), f"{a / 28 * 100:.1f}%", f"{tot - fal} / {fal}"))
    preencher_tabela(evo, evo_rows, [1000, 1000, 1400, 1400, 1400, 1300, 2436])
    manter_junto(evo)
    p_evo.find(qn("w:pPr")).insert(0, etree.Element(qn("w:keepNext")))
    esp2 = copy.deepcopy(P(50))
    P(147).addnext(esp2)
    esp2.addnext(p_evo)
    p_evo.addnext(evo)

    # ---- 16. relatório final
    a1, r1 = contagem(1)
    a2, r2 = contagem(2)
    trocar_texto(P(150),
        f"Em {DATA} foram executados três ciclos de teste com pytest sobre as versões v0.1.0, v0.2.0 e v1.0.0 do sistema. "
        f"Ciclo 1: {a1} dos 28 casos aprovados e {r1} reprovados (17 de 83 execuções falharam), revelando 8 defeitos (BUG001–BUG008, "
        f"entre eles o requisito RF07 – trancamento – ainda não implementado). Após a primeira rodada de correções, o Ciclo 2 teve {a2} casos aprovados e {r2} "
        f"reprovados (4 de 83 execuções): BUG005 e BUG006 permaneciam abertos e o reteste do trancamento revelou o BUG009, antes mascarado. "
        f"Após a segunda rodada, o Ciclo 3 aprovou os 28 casos (83 de 83 execuções), com 100% de aprovação, 9 defeitos corrigidos e nenhum pendente.")
    res_ft = [
        ("FT01 – Cadastro de alunos (CT001–CT004)", "Aprovado", "BUG007 (CPF duplicado aceito) corrigido."),
        ("FT02 – Cadastro de disciplinas (CT005–CT006)", "Aprovado", "Sem defeitos."),
        ("FT03 – Matrícula (CT007–CT011)", "Aprovado", "BUG004 (vaga N+1) e BUG005 (pré-requisitos) corrigidos."),
        ("FT04 – Notas e frequência (CT012–CT015)", "Aprovado", "BUG003 (nota negativa aceita) corrigido."),
        ("FT05 – Situação final (CT016–CT020)", "Aprovado", "BUG001 (média 7,0) e BUG002 (frequência 75%) corrigidos."),
        ("FT06 – Trancamento (CT021–CT023, CT028)", "Aprovado", "RF07 não implementado na v0.1.0 (BUG008); BUG009 (vaga não liberada) corrigido."),
        ("FT07 – Histórico e CR (CT024, CT025, CT027)", "Aprovado", "BUG006 (CR por média simples) corrigido."),
        ("FT08 – Relatório da disciplina (CT026)", "Aprovado", "Reprovado no Ciclo 1 por efeito do BUG001; aprovado após a correção."),
    ]
    preencher_tabela(P(152), res_ft, [3600, 1500, 4836], col_status=(1,))
    preencher_tabela(P(154), RISCOS, [3600, 1100, 1300, 3936])
    trocar_texto(P(156),
        "O sistema, na versão v1.0.0, atende a todos os requisitos avaliados (RF01–RF09 e RN01–RN17): os 28 casos de teste foram aprovados. "
        "Foram encontrados 9 defeitos — 7 comportamentos incorretos em regras de negócio (BUG001–BUG007, incluindo três falhas de valor-limite), "
        "1 requisito não implementado (BUG008, trancamento) e 1 defeito de integração revelado no reteste (BUG009) — todos corrigidos e retestados, "
        "sem defeitos pendentes. Todos os requisitos do escopo estão implementados na versão final; persistência, autenticação, interface "
        "e testes não funcionais permanecem fora do escopo (seção 16.3). O sistema está apto para a apresentação final.")

    # ---- 17. aprovação
    preencher_tabela(P(158), [(R1, "Representante da equipe", f"[Assinatura] {DATA}"), (PROFESSOR, "Professor", "[Assinatura/Data]")], [3500, 3000, 3436])

    # ---- remove o parágrafo vazio final do template (evita página em branco)
    ult = P(159)
    if not texto_de(ult).strip():
        corpo.remove(ult)

    # ---- propriedades
    cp = doc.core_properties
    cp.title = "Especificação e Planejamento de Testes – Sistema de Controle Acadêmico"
    cp.author = "Equipe A3 – Garantia da Qualidade de Software"
    cp.comments = ""
    doc.save(saida)
    print("salvo:", saida)


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
