#!/usr/bin/env bash
# Uso: scripts/rodar_ciclo.sh <ciclo> <versao>   ex.: scripts/rodar_ciclo.sh ciclo1 v0.1.0
# <versao> = v0.1.0 | v0.2.0 | atual (src/ = v1.0.0)
set -u
CICLO="$1"; VERSAO="$2"
DEST="evidencias/${CICLO}_${VERSAO}"; mkdir -p "$DEST"
if [ "$VERSAO" = "atual" ]; then PP="src tests"; else PP="versoes/${VERSAO} tests"; fi
{
  echo "# Ciclo: ${CICLO} | Versão do sistema: ${VERSAO} | Ferramenta: pytest"
  echo "# Execução: $(date '+%d/%m/%Y %H:%M:%S')"
  python3 -m pytest -o pythonpath="$PP" -v --tb=short --junitxml="$DEST/resultado.xml" -p no:cacheprovider
} > "$DEST/log_pytest.txt" 2>&1
tail -n 40 "$DEST/log_pytest.txt"
