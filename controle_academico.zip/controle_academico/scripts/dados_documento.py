# -*- coding: utf-8 -*-
"""Conteúdo do documento de especificação de testes (texto que preenche o template)."""

DATA = "10/11/2026"
R1, R2, R3, R4 = "[Integrante 1]", "[Integrante 2]", "[Integrante 3]", "[Integrante 4]"
PROFESSOR = "Enderson Nobre Santos"

ARQ = {
    "cad": "tests/test_ct_cadastros.py",
    "mat": "tests/test_ct_matricula.py",
    "ava": "tests/test_ct_avaliacao.py",
    "tra": "tests/test_ct_trancamento_historico.py",
}

# ---------------------------------------------------------------- escopo / requisitos
FUNCIONALIDADES = [
    ("FT01", "Cadastro de alunos", "Cadastro com validação de nome, CPF (dígitos verificadores e unicidade) e e-mail; geração de matrícula sequencial (RF01)."),
    ("FT02", "Cadastro de disciplinas", "Código único, carga horária, vagas e pré-requisitos (RF02)."),
    ("FT03", "Matrícula em disciplina", "Matrícula por semestre com controle de vagas, pré-requisitos, duplicidade e limite de 6 disciplinas (RF03)."),
    ("FT04", "Notas e frequência", "Lançamento de N1, N2 e exame final (0 a 10), registro de aulas dadas e faltas (RF04, RF05)."),
    ("FT05", "Situação final", "Cálculo de média, frequência e apuração de aprovação, exame final e reprovações (RF06)."),
    ("FT06", "Trancamento de matrícula", "Trancamento de matrícula em andamento, com liberação de vaga (RF07)."),
    ("FT07", "Histórico escolar e CR", "Histórico por aluno e Coeficiente de Rendimento ponderado pela carga horária (RF08)."),
    ("FT08", "Relatório da disciplina", "Lista de alunos, média da turma e taxa de aprovação por semestre (RF09)."),
]

FORA_ESCOPO = [
    ("Interface gráfica / Web", "O sistema é uma biblioteca de domínio (back-end); não há telas para testar."),
    ("Persistência em banco de dados", "Os dados ficam em memória durante a execução; persistência não faz parte desta versão."),
    ("Autenticação e perfis de acesso", "Não implementados; fora do escopo do trabalho A3."),
    ("Testes de desempenho e carga", "Volume de dados e tempo de resposta não são requisitos desta versão."),
    ("Cadastro de professores, turmas e grade horária", "Funcionalidades não previstas na especificação do sistema."),
]

PUBLICO = [
    ("Secretaria acadêmica", "Cadastra alunos e disciplinas, realiza matrículas e trancamentos e emite relatórios."),
    ("Professor", "Lança notas, exame final e frequência e consulta o relatório da disciplina."),
    ("Aluno", "Consulta histórico escolar, situação nas disciplinas e Coeficiente de Rendimento (CR)."),
]

TECNOLOGIAS = [
    ("Front-end", "Não se aplica (biblioteca de domínio). Demonstração em linha de comando: main.py."),
    ("Back-end", "Python 3.13 (pacote academico: models, validators, services, regras, exceptions)."),
    ("Banco de dados", "Não se aplica — armazenamento em memória (dicionários e listas)."),
    ("Ambiente de execução", "Linux (container), Python 3.13.18."),
    ("Ferramentas de teste", "pytest 9.1.1 (parametrização, fixtures, marcadores, relatório JUnit XML)."),
    ("Controle de versão", "Git/GitHub (repositório da equipe) — snapshots versoes/v0.1.0, v0.2.0 e src/ (v1.0.0) e patches em evidencias/."),
]

REFERENCIAS = [
    ("RF01–RF09", "Requisitos funcionais definidos na seção 7 deste documento."),
    ("RN01–RN17", "Regras de negócio definidas na seção 7 deste documento."),
    ("UC01–UC06", "Casos de uso: UC01 Gerenciar alunos; UC02 Gerenciar disciplinas; UC03 Realizar matrícula e trancamento; UC04 Lançar avaliações e frequência; UC05 Apurar resultado final; UC06 Consultar histórico e relatórios."),
    ("Trabalho A3 – Teste de Software", "Enunciado e barema da UC Garantia da Qualidade de Software (Prof. Enderson Nobre Santos)."),
    ("Código-fonte", "src/academico/ (versão final v1.0.0) e versoes/ (versões anteriores com defeitos)."),
    ("Suíte automatizada", "tests/ — 28 casos de teste (CT001 a CT028) implementados em pytest, 83 execuções parametrizadas."),
]

NIVEIS = [
    ("Unidade", "Sim", "Validadores (CPF, e-mail, nota) e cálculos de média, frequência e situação (CT001–CT006, CT012–CT020)."),
    ("Integração", "Sim", "Interação entre matrícula, trancamento, histórico e relatório (CT022, CT025, CT026, CT028)."),
    ("Sistema", "Sim", "Fluxo completo de um semestre, do cadastro ao CR (CT027)."),
    ("Aceitação", "Não", "Exigiria validação com usuários reais da secretaria; fora do escopo do trabalho."),
]

TIPOS = [
    ("Funcional", "Sim", "Verificar que cada requisito funcional produz o resultado esperado."),
    ("Negativo", "Sim", "Entradas inválidas e operações proibidas pelas regras de negócio."),
    ("Regressão", "Sim", "Reexecutar toda a suíte (83 execuções) após cada rodada de correções."),
    ("Interface", "Não", "Não há interface gráfica."),
    ("Desempenho", "Não", "Não há requisito de tempo de resposta ou carga."),
    ("Segurança", "Não", "Não há autenticação nem autorização nesta versão."),
    ("Usabilidade", "Não", "Não há interface com usuário final."),
]

AMBIENTE = [
    ("Sistema operacional", "Linux 6.x (container Anthropic cloud)"),
    ("Navegador", "Não se aplica"),
    ("Banco de dados", "Não se aplica (memória)"),
    ("Servidor/URL", "Não se aplica — execução local: python -m pytest"),
    ("Versão do sistema", "v0.1.0 (ciclo 1), v0.2.0 (ciclo 2), v1.0.0 (ciclo 3)"),
    ("Ferramentas", "Python 3.13.18, pytest 9.1.1, scripts/rodar_ciclo.sh"),
]

DADOS_TESTE = [
    ("CPFs", "CPFs válidos gerados por tests/helpers.py::gerar_cpf (dígitos verificadores corretos); exemplos fixos: 529.982.247-25 e 111.444.777-35."),
    ("Alunos", "Criados por fixtures/auxiliares (novo_aluno) com nome, CPF e e-mail únicos; matrículas sequenciais a partir de 20260001."),
    ("Disciplinas", "QS101 (60 h, 40 vagas), MAT101, PRG101, ED201 (pré-requisitos MAT101 e PRG101) e D001–D007 (limite semestral)."),
    ("Semestres", "2026.1, 2026.2 e 2027.1 (formato AAAA.S)."),
    ("Isolamento", "Cada teste recebe um SistemaAcademico novo (fixture 'sistema'); não há dependência entre testes."),
]

# ---------------------------------------------------------------- requisitos
REQUISITOS = [
    ("RF01", "Funcional", "Cadastrar aluno (nome, CPF, e-mail) gerando matrícula única.", "Alta", "UC01"),
    ("RF02", "Funcional", "Cadastrar disciplina (código, nome, carga horária, vagas, pré-requisitos).", "Alta", "UC02"),
    ("RF03", "Funcional", "Matricular aluno em disciplina em um semestre.", "Alta", "UC03"),
    ("RF04", "Funcional", "Lançar notas N1, N2 e exame final.", "Alta", "UC04"),
    ("RF05", "Funcional", "Registrar aulas dadas e faltas.", "Média", "UC04"),
    ("RF06", "Funcional", "Apurar a situação final do aluno na disciplina.", "Alta", "UC05"),
    ("RF07", "Funcional", "Trancar matrícula em andamento.", "Alta", "UC03"),
    ("RF08", "Funcional", "Emitir histórico escolar e Coeficiente de Rendimento (CR).", "Média", "UC06"),
    ("RF09", "Funcional", "Emitir relatório da disciplina (alunos, média da turma, taxa de aprovação).", "Média", "UC06"),
    ("RN01", "Regra de negócio", "O CPF deve ser válido (11 dígitos e dígitos verificadores corretos).", "Alta", "UC01"),
    ("RN02", "Regra de negócio", "Não podem existir dois alunos com o mesmo CPF.", "Alta", "UC01"),
    ("RN03", "Regra de negócio", "O e-mail deve ter formato válido.", "Média", "UC01"),
    ("RN04", "Regra de negócio", "Carga horária e vagas são inteiros maiores que zero; o código da disciplina é único.", "Média", "UC02"),
    ("RN05", "Regra de negócio", "A matrícula não pode exceder o número de vagas da disciplina no semestre.", "Alta", "UC03"),
    ("RN06", "Regra de negócio", "Todos os pré-requisitos devem ter sido concluídos com aprovação.", "Alta", "UC03"),
    ("RN07", "Regra de negócio", "Não é permitida matrícula duplicada (mesma disciplina e semestre) nem em disciplina já aprovada.", "Média", "UC03"),
    ("RN08", "Regra de negócio", "Máximo de 6 disciplinas ativas por aluno em cada semestre.", "Média", "UC03"),
    ("RN09", "Regra de negócio", "Notas devem ser numéricas entre 0 e 10 (inclusive).", "Alta", "UC04"),
    ("RN10", "Regra de negócio", "Média parcial = (N1 + N2) / 2.", "Alta", "UC04"),
    ("RN11", "Regra de negócio", "Aprovação direta: média parcial ≥ 7,0 e frequência ≥ 75%.", "Alta", "UC05"),
    ("RN12", "Regra de negócio", "Com 4,0 ≤ média < 7,0 o aluno faz exame final; aprovado se (média + final)/2 ≥ 5,0. A nota FINAL só pode ser lançada nesse caso.", "Alta", "UC05"),
    ("RN13", "Regra de negócio", "Frequência < 75% reprova por falta, independentemente da nota.", "Alta", "UC05"),
    ("RN14", "Regra de negócio", "Média parcial < 4,0 reprova por nota, sem exame final.", "Alta", "UC05"),
    ("RN15", "Regra de negócio", "CR = média das médias finais ponderada pela carga horária das disciplinas concluídas.", "Alta", "UC06"),
    ("RN16", "Regra de negócio", "Só se tranca matrícula em andamento; o trancamento libera a vaga e o limite semestral e a matrícula não entra no CR.", "Alta", "UC03"),
    ("RN17", "Regra de negócio", "Faltas devem ser inteiras, entre 0 e o total de aulas dadas (> 0).", "Média", "UC04"),
]

TECNICAS = [
    ("Particionamento de equivalência", "Sim", "Classes válidas e inválidas de CPF, e-mail, carga horária/vagas e semestre (CT001–CT007)."),
    ("Análise de valor-limite", "Sim", "Notas 0/10, média 4,0/7,0, frequência 75%, vagas N/N+1, 6ª/7ª disciplina (CT009, CT011, CT013, CT015–CT019)."),
    ("Tabela de decisão", "Sim", "Pré-requisitos (CT010) e situação final / exame final (CT016–CT019), conforme tabela abaixo."),
    ("Testes de cenários", "Sim", "Fluxos de negócio ponta a ponta e regressão (CT022, CT024–CT028)."),
]

DECISAO = [
    ("Não (< 75%)", "qualquer", "—", "REPROVADO_POR_FALTA (RN13)"),
    ("Sim", "≥ 7,0", "—", "APROVADO (RN11)"),
    ("Sim", "< 4,0", "—", "REPROVADO_POR_NOTA (RN14)"),
    ("Sim", "4,0 ≤ média < 7,0", "ainda não lançada", "EM_EXAME_FINAL (RN12)"),
    ("Sim", "4,0 ≤ média < 7,0", "(média + final)/2 ≥ 5,0", "APROVADO (RN12)"),
    ("Sim", "4,0 ≤ média < 7,0", "(média + final)/2 < 5,0", "REPROVADO_POR_NOTA (RN12)"),
]

# ---------------------------------------------------------------- casos de teste
# chave: (nome, req, uc, prio, tipo, tecnica, resp, pre, entrada, passos, esperado, arquivo, obs_extra)
CASOS = {
"CT001": ("Cadastrar aluno com dados válidos", "RF01", "UC01 – Gerenciar alunos", "Alta", "Funcional", "Particionamento de equivalência (classe válida)", R1, "Sistema acadêmico vazio.",
  "Nome: João Pereira; CPF: 529.982.247-25; e-mail: joao@exemplo.com. Segundo aluno: 'Aluno Teste 2' com outro CPF válido.",
  ["Instanciar SistemaAcademico.", "Chamar cadastrar_aluno com os dados informados.", "Consultar o aluno com obter_aluno('20260001').", "Cadastrar um segundo aluno."],
  "Aluno criado com matrícula 20260001; CPF armazenado apenas com dígitos (52998224725); o segundo aluno recebe a matrícula 20260002 (sequencial e única).", "cad"),
"CT002": ("Rejeitar cadastro com CPF inválido", "RF01, RN01", "UC01 – Gerenciar alunos", "Alta", "Negativo", "Particionamento de equivalência (classes inválidas)", R1, "Sistema acadêmico vazio.",
  "CPFs: 123.456.789-00 (dígitos verificadores errados); 111.111.111-11 (repetidos); 1234 (curto); '' (vazio); abcdefghijk (não numérico); 529.982.247-24 (DV alterado).",
  ["Chamar cadastrar_aluno com cada CPF inválido, nome e e-mail válidos."],
  "ValidacaoError é lançada para cada um dos 6 CPFs inválidos.", "cad"),
"CT003": ("Rejeitar cadastro com CPF já cadastrado", "RN02", "UC01 – Gerenciar alunos", "Alta", "Negativo", "Particionamento de equivalência", R1, "Aluno com CPF 529.982.247-25 já cadastrado.",
  "Nome: Outro Aluno; CPF: 52998224725 (mesmo CPF, sem máscara); e-mail: outro@exemplo.com.",
  ["Cadastrar o primeiro aluno.", "Tentar cadastrar o segundo aluno com o mesmo CPF."],
  "RegraNegocioError ('CPF já cadastrado') e o segundo aluno não é criado.", "cad"),
"CT004": ("Rejeitar cadastro com e-mail inválido", "RN03", "UC01 – Gerenciar alunos", "Média", "Validação", "Particionamento de equivalência (classes inválidas)", R1, "Sistema acadêmico vazio.",
  "E-mails: semarroba.com; a@; @b.com; 'a b@c.com'; a@b; '' (vazio).",
  ["Chamar cadastrar_aluno com CPF válido e cada e-mail inválido."],
  "ValidacaoError para cada e-mail inválido.", "cad"),
"CT005": ("Cadastrar disciplina válida e tratar duplicidade/pré-requisito inexistente", "RF02, RN04", "UC02 – Gerenciar disciplinas", "Alta", "Funcional", "Particionamento de equivalência", R1, "Sistema acadêmico vazio.",
  "MAT101 'Matemática' (60 h, 30 vagas); MAT201 'Cálculo' (80 h, 25 vagas, pré-requisito mat101); código repetido MAT101; pré-requisito XXX999 inexistente.",
  ["Cadastrar MAT101 com código em minúsculas ('mat101').", "Cadastrar MAT201 com pré-requisito 'mat101'.", "Consultar as disciplinas.", "Cadastrar MAT101 novamente.", "Cadastrar disciplina com pré-requisito inexistente."],
  "Códigos normalizados em maiúsculas; MAT201 guarda ('MAT101',) como pré-requisito; duplicidade → RegraNegocioError; pré-requisito inexistente → NaoEncontradoError.", "cad"),
"CT006": ("Rejeitar carga horária ou vagas inválidas", "RN04", "UC02 – Gerenciar disciplinas", "Média", "Validação", "Análise de valor-limite", R1, "Sistema acadêmico vazio.",
  "(carga horária; vagas): (0; 10), (-60; 10), (60; 0), (60; -1), (60,5; 10), ('60'; 10); limite válido: (1; 1).",
  ["Chamar cadastrar_disciplina com cada par inválido.", "Cadastrar disciplina com carga 1 e 1 vaga (menor valor válido)."],
  "ValidacaoError para os 6 pares inválidos; o par (1; 1) é aceito.", "cad"),
"CT007": ("Matricular aluno em disciplina com vaga disponível", "RF03", "UC03 – Realizar matrícula", "Alta", "Funcional", "Particionamento de equivalência", R2, "Aluno cadastrado e disciplina QS101 (40 vagas) cadastrada.",
  "Matrícula do aluno, disciplina QS101, semestre 2026.2; entidades inexistentes: aluno 99999999 e disciplina ZZZ999.",
  ["Chamar matricular(aluno, 'QS101', '2026.2').", "Consultar a situação.", "Tentar matricular aluno e disciplina inexistentes."],
  "Matrícula criada com status CURSANDO e situação EM_ANDAMENTO; entidades inexistentes → NaoEncontradoError.", "mat"),
"CT008": ("Impedir matrícula duplicada ou em disciplina já aprovada", "RN07", "UC03 – Realizar matrícula", "Média", "Negativo", "Particionamento de equivalência", R2, "Aluno matriculado em QS101 em 2026.2.",
  "Mesma matrícula repetida em 2026.2; após aprovação (N1=8, N2=9, 40 aulas, 0 faltas), nova matrícula em QS101 em 2027.1.",
  ["Matricular novamente o aluno em QS101/2026.2.", "Concluir a disciplina com aprovação.", "Tentar matricular em QS101/2027.1."],
  "RegraNegocioError nas duas tentativas.", "mat"),
"CT009": ("Impedir matrícula quando as vagas estão esgotadas", "RN05", "UC03 – Realizar matrícula", "Alta", "Negativo", "Análise de valor-limite (N e N+1 vagas)", R2, "Disciplina QS101 com 2 vagas e 3 alunos cadastrados.",
  "Alunos A1, A2 e A3; disciplina QS101; semestre 2026.2.",
  ["Matricular A1.", "Matricular A2 (ocupa a última vaga).", "Tentar matricular A3."],
  "A1 e A2 são matriculados; a matrícula de A3 (vaga N+1) é negada com RegraNegocioError.", "mat"),
"CT010": ("Exigir que todos os pré-requisitos estejam aprovados", "RN06", "UC03 – Realizar matrícula", "Alta", "Negativo", "Tabela de decisão", R2, "MAT101, PRG101 e ED201 (pré-requisitos MAT101 e PRG101) cadastradas; aluno sem histórico.",
  "Cenários: (a) nenhum pré-requisito cumprido; (b) só MAT101 aprovada; (c) MAT101 e PRG101 aprovadas; (d) MAT101 reprovada por nota (3 e 3).",
  ["Tentar matricular em ED201 sem pré-requisitos.", "Aprovar MAT101 e tentar novamente.", "Aprovar PRG101 e tentar novamente.", "Em outro cenário, reprovar em MAT101 e tentar matricular em MAT201."],
  "(a) e (b) negadas com RegraNegocioError; (c) permitida; (d) negada — pré-requisito reprovado não conta.", "mat"),
"CT011": ("Limitar a 6 disciplinas por semestre", "RN08", "UC03 – Realizar matrícula", "Média", "Negativo", "Análise de valor-limite (6ª e 7ª matrícula)", R2, "Aluno cadastrado e 7 disciplinas (D001–D007) cadastradas.",
  "Matrículas em D001 a D006 no semestre 2026.2; 7ª disciplina em 2026.2 e em 2027.1.",
  ["Matricular o aluno em 6 disciplinas em 2026.2.", "Tentar a 7ª matrícula em 2026.2.", "Matricular na 7ª disciplina em 2027.1."],
  "6 matrículas aceitas; a 7ª em 2026.2 é negada (RegraNegocioError); em 2027.1 é aceita.", "mat"),
"CT012": ("Lançar N1 e N2 e calcular a média parcial", "RF04, RN10", "UC04 – Lançar avaliações e frequência", "Alta", "Funcional", "Particionamento de equivalência", R3, "Aluno matriculado em QS101 em 2026.2.",
  "N1 = 6,5; N2 = 8,0.",
  ["Consultar a média sem notas.", "Lançar N1 e consultar a média.", "Lançar N2 e consultar a média."],
  "Média indefinida (None) enquanto faltar nota; após N1 e N2, média = 7,25.", "ava"),
"CT013": ("Validar a faixa de notas (0 a 10)", "RF04, RN09", "UC04 – Lançar avaliações e frequência", "Alta", "Validação", "Análise de valor-limite", R3, "Aluno matriculado em QS101 em 2026.2.",
  "Inválidas: -0,1; -1; 10,1; 11; 100; '8' (texto); None; True. Válidas: 0; 0,0; 0,1; 9,9; 10; 10,0.",
  ["Lançar N1 com cada valor inválido.", "Lançar N1 com cada valor válido."],
  "ValidacaoError para os valores inválidos; os valores limite 0 e 10 (e intermediários) são aceitos e gravados.", "ava"),
"CT014": ("Registrar frequência e calcular o percentual", "RF05", "UC04 – Lançar avaliações e frequência", "Média", "Funcional", "Particionamento de equivalência", R3, "Aluno matriculado em QS101 em 2026.2.",
  "40 aulas dadas e 10 faltas; depois 40 aulas e 0 faltas.",
  ["Consultar frequência sem registro.", "Registrar 40 aulas / 10 faltas.", "Registrar 40 aulas / 0 faltas."],
  "Frequência indefinida (None) sem registro; 75,0% com 10 faltas; 100,0% com 0 faltas.", "ava"),
"CT015": ("Rejeitar registro de frequência inválido", "RF05, RN17", "UC04 – Lançar avaliações e frequência", "Média", "Negativo", "Análise de valor-limite", R3, "Aluno matriculado em QS101 em 2026.2.",
  "(aulas; faltas): (40; 41), (40; -1), (0; 0), (-5; 0), (40; 2,5), (40; '3'); limite válido: (40; 40).",
  ["Registrar cada par inválido.", "Registrar 40 aulas com 40 faltas."],
  "ValidacaoError nos 6 pares inválidos; (40; 40) é aceito e resulta em frequência 0,0%.", "ava"),
"CT016": ("Aprovação direta com média ≥ 7,0 e frequência ≥ 75%", "RF06, RN11", "UC05 – Apurar resultado final", "Alta", "Funcional", "Análise de valor-limite (média 7,0)", R3, "Aluno matriculado em QS101; 40 aulas e 0 faltas.",
  "(N1; N2): (7; 7), (6,9; 7,1), (7,5; 6,5) e (10; 10) → média ≥ 7,0; (6,5; 7,0) → média 6,75.",
  ["Lançar N1, N2 e frequência para cada par.", "Consultar a situação."],
  "APROVADO para médias 7,0 (limite exato), 7,0, 7,0 e 10,0; EM_EXAME_FINAL para média 6,75.", "ava"),
"CT017": ("Reprovação por falta com frequência < 75%", "RF06, RN13", "UC05 – Apurar resultado final", "Alta", "Funcional", "Análise de valor-limite (frequência 75%)", R3, "Aluno matriculado em QS101; N1 = N2 = 10; 40 aulas dadas.",
  "Faltas: 0 (100%), 10 (75,0%), 11 (72,5%), 40 (0%).",
  ["Registrar notas 10 e 10.", "Registrar frequência para cada quantidade de faltas.", "Consultar a situação."],
  "APROVADO com 0 e 10 faltas (75,0% é suficiente); REPROVADO_POR_FALTA com 11 e 40 faltas, mesmo com média 10.", "ava"),
"CT018": ("Reprovação direta por nota com média < 4,0", "RN14", "UC05 – Apurar resultado final", "Alta", "Funcional", "Análise de valor-limite (média 4,0)", R3, "Aluno matriculado em QS101; 40 aulas e 0 faltas.",
  "(N1; N2): (0; 0), (3,9; 3,9) e (4; 4).",
  ["Lançar as notas e a frequência.", "Consultar a situação."],
  "REPROVADO_POR_NOTA para médias 0,0 e 3,9; EM_EXAME_FINAL para média 4,0 (limite).", "ava"),
"CT019": ("Exame final: aprovado se (média + final) / 2 ≥ 5,0", "RF06, RN12", "UC05 – Apurar resultado final", "Alta", "Funcional", "Tabela de decisão + valor-limite", R3, "Aluno matriculado em QS101 com média parcial entre 4,0 e 6,99 (EM_EXAME_FINAL).",
  "(N1; N2; FINAL): (5; 5; 5) → 5,0; (4; 4; 6) → 5,0; (4; 5; 5) → 4,75; (6; 6,8; 3) → 4,7; (6; 6,8; 10) → 8,2.",
  ["Lançar N1, N2 e frequência e confirmar EM_EXAME_FINAL.", "Lançar a nota FINAL.", "Consultar média final e situação."],
  "Média final 5,0 aprova (limite); 4,75 e 4,7 reprovam (REPROVADO_POR_NOTA); 8,2 aprova.", "ava"),
"CT020": ("Impedir lançamento da nota FINAL fora do exame final", "RN12", "UC05 – Apurar resultado final", "Média", "Negativo", "Particionamento de equivalência", R3, "Aluno matriculado em QS101 em 2026.2.",
  "FINAL = 8: (a) aluno sem notas; (b) aluno aprovado direto (N1 = N2 = 9).",
  ["Lançar FINAL sem notas.", "Concluir a disciplina com aprovação direta.", "Lançar FINAL novamente."],
  "RegraNegocioError em ambos os casos ('Aluno não está em exame final').", "ava"),
"CT021": ("Trancar matrícula em andamento", "RF07, RN16", "UC03 – Realizar matrícula (trancamento)", "Alta", "Funcional", "Particionamento de equivalência (transição de estado)", R4, "Aluno matriculado em QS101 em 2026.2.",
  "Matrícula, disciplina QS101, semestre 2026.2; N1 = 8 após o trancamento.",
  ["Chamar trancar_matricula.", "Consultar status e situação.", "Tentar lançar N1.", "Tentar trancar novamente."],
  "Status TRANCADA e situação TRANCADA; lançamento de nota e novo trancamento → RegraNegocioError.", "tra"),
"CT022": ("Trancamento libera vaga e limite semestral", "RN05, RN08, RN16", "UC03 – Realizar matrícula (trancamento)", "Alta", "Integração", "Testes de cenários", R4, "(a) QS101 com 1 vaga e 2 alunos; (b) aluno com 6 matrículas ativas em 2026.2.",
  "(a) A1 ocupa a vaga; A2 tenta matricular antes e depois do trancamento de A1. (b) trancar D006 e matricular em D007.",
  ["Matricular A1; tentar matricular A2 (turma cheia).", "Trancar a matrícula de A1.", "Matricular A2.", "Cenário (b): trancar uma das 6 matrículas e matricular em outra disciplina."],
  "Antes do trancamento A2 é negado; depois, A2 é matriculado e o relatório mostra 1 aluno; no cenário (b) a 7ª disciplina é aceita após o trancamento.", "tra"),
"CT023": ("Impedir trancar disciplina concluída ou matrícula inexistente", "RN16", "UC03 – Realizar matrícula (trancamento)", "Média", "Negativo", "Particionamento de equivalência", R4, "Aluno aprovado em QS101 (N1 = N2 = 9); aluno sem matrícula.",
  "Trancamento de QS101/2026.2 do aluno aprovado; trancamento de matrícula inexistente.",
  ["Concluir a disciplina com aprovação.", "Tentar trancar.", "Tentar trancar matrícula que não existe."],
  "Disciplina concluída → RegraNegocioError; matrícula inexistente → NaoEncontradoError.", "tra"),
"CT024": ("Emitir histórico escolar do aluno", "RF08", "UC06 – Consultar histórico e relatórios", "Média", "Funcional", "Testes de cenários", R4, "Aluno com PRG101 (8 e 9; 4 faltas em 40 aulas) e MAT101 (2 e 3) em 2026.1 e matriculado em MAT101 em 2026.2.",
  "Matrícula do aluno.",
  ["Montar o cenário.", "Chamar historico(matricula)."],
  "Três linhas ordenadas por semestre/código: 2026.1 MAT101 REPROVADO_POR_NOTA; 2026.1 PRG101 APROVADO (média 8,5; frequência 90%); 2026.2 MAT101 EM_ANDAMENTO.", "tra"),
"CT025": ("Calcular o CR ponderado pela carga horária", "RF08, RN15", "UC06 – Consultar histórico e relatórios", "Alta", "Funcional", "Particionamento de equivalência", R4, "MAT101 (40 h) e PRG101 (80 h) cadastradas; aluno matriculado nas duas em 2026.1.",
  "MAT101: N1 = N2 = 9 (média 9,0). PRG101: N1 = N2 = 6 e FINAL = 6 (média final 6,0). Aluno sem disciplinas concluídas.",
  ["Concluir MAT101 e deixar PRG101 em exame final; calcular o CR.", "Lançar FINAL = 6 em PRG101; calcular o CR.", "Calcular o CR de aluno sem disciplinas concluídas."],
  "CR = 9,0 (EM_EXAME_FINAL não entra); depois CR = (9×40 + 6×80)/120 = 7,0 (a média simples seria 7,5); aluno sem concluídas → 0,0.", "tra"),
"CT026": ("Emitir relatório da disciplina (média da turma e taxa de aprovação)", "RF09", "UC06 – Consultar histórico e relatórios", "Média", "Integração", "Testes de cenários", R4, "QS101 com 4 alunos matriculados em 2026.2.",
  "Aluno 1: 9 e 9; aluno 2: 7 e 7; aluno 3: 2 e 2; aluno 4 apenas matriculado.",
  ["Concluir as disciplinas dos alunos 1 a 3.", "Chamar relatorio_disciplina('QS101', '2026.2')."],
  "total_alunos = 4; aprovados = 2; taxa de aprovação = 66,67%; média da turma = 6,0; situações APROVADO, REPROVADO_POR_NOTA e EM_ANDAMENTO.", "tra"),
"CT027": ("Fluxo completo do semestre (cadastro → matrícula → notas → situação → CR)", "RF01–RF08, RN11–RN13, RN15", "UC01 a UC06", "Alta", "Sistema", "Testes de cenários", R4, "Sistema vazio.",
  "Disciplinas MAT101 (60 h, 2 vagas) e MAT201 (pré-requisito MAT101); alunos Ana Souza e Bia Lima; notas e faltas conforme o cenário.",
  ["Cadastrar disciplinas e alunos.", "2026.1: Ana tira 8 e 8; Bia tira 5 e 5 e FINAL 7 em MAT101.", "2026.2: ambas cursam MAT201; Ana tira 10 e 10; Bia tira 10 e 10 com 20 faltas em 40 aulas.", "Consultar situações, CR e histórico."],
  "Bia aprovada por exame final (6,0); em MAT201 Ana APROVADA e Bia REPROVADO_POR_FALTA (50%); CR de Ana = 9,0 e de Bia = 8,0; histórico de Ana com 2 linhas.", "tra"),
"CT028": ("Regressão: trancamento não afeta as demais matrículas", "RF07, RF08, RF09", "UC03 e UC06", "Baixa", "Regressão", "Testes de cenários", R4, "Aluno aprovado em MAT101 (8 e 8) e matriculado em PRG101 em 2026.2.",
  "Trancar PRG101; consultar histórico, CR e relatório; rematricular em PRG101.",
  ["Trancar PRG101.", "Consultar histórico, CR e relatório da disciplina.", "Matricular novamente em PRG101."],
  "Histórico: MAT101 APROVADO e PRG101 TRANCADA; CR = 8,0; relatório de PRG101 com 0 alunos; rematrícula aceita e situação EM_ANDAMENTO.", "tra"),
}

# Ciclos em que cada CT reprovou (conferido contra os XMLs do pytest na geração) e descrição do que ocorreu
FALHAS = {
"CT003": {1: "o segundo cadastro com o mesmo CPF foi aceito (DID NOT RAISE RegraNegocioError) — BUG007."},
"CT009": {1: "a matrícula do 3º aluno foi aceita com 2/2 vagas ocupadas (vaga N+1) — BUG004."},
"CT010": {1: "matrícula em ED201 permitida com apenas 1 de 2 pré-requisitos aprovado — BUG005.",
          2: "defeito BUG005 ainda aberto na v0.2.0; matrícula permitida com 1 de 2 pré-requisitos."},
"CT013": {1: "notas -0,1 e -1 foram aceitas (DID NOT RAISE ValidacaoError) — BUG003."},
"CT016": {1: "médias 7,0 retornaram EM_EXAME_FINAL em vez de APROVADO (3 execuções) — BUG001."},
"CT017": {1: "com 10 faltas em 40 aulas (75,0%) retornou REPROVADO_POR_FALTA em vez de APROVADO — BUG002."},
"CT021": {1: "NotImplementedError: 'RF07 - trancamento de matrícula ainda não implementado' — BUG008."},
"CT022": {1: "turma cheia aceitou o 2º aluno (BUG004) e o trancamento lançou NotImplementedError (BUG008).",
          2: "após trancar, a vaga e o limite semestral não foram liberados: 'Não há vagas disponíveis' e 'Limite de disciplinas atingido' — BUG009."},
"CT023": {1: "NotImplementedError ao chamar trancar_matricula — BUG008."},
"CT025": {1: "CR obtido 7,5 (média simples) em vez de 7,0 (ponderado) — BUG006.",
          2: "defeito BUG006 ainda aberto na v0.2.0; CR obtido 7,5 em vez de 7,0."},
"CT026": {1: "aprovados = 1 em vez de 2: o aluno com média 7,0 ficou em exame final (efeito do BUG001)."},
"CT028": {1: "NotImplementedError ao chamar trancar_matricula — BUG008."},
}

CICLOS = {
    1: ("Ciclo 1", "v0.1.0", "evidencias/ciclo1_v0.1.0"),
    2: ("Ciclo 2", "v0.2.0", "evidencias/ciclo2_v0.2.0"),
    3: ("Ciclo 3", "v1.0.0", "evidencias/ciclo3_atual"),
}

# ---------------------------------------------------------------- defeitos
# código: (título, CTs, requisito, severidade, prioridade, id_resp, corr_resp, ciclo_id, passos, esperado, obtido, causa/correção, rodada_correção)
DEFEITOS = [
("BUG001", "Média exatamente 7,0 não aprova o aluno diretamente (vai para exame final)", "CT016 (e CT026)", "RN11 / RF06", "Alta", "Alta", R3, R3, 1,
  ["Matricular o aluno em QS101/2026.2.", "Lançar N1 = 7 e N2 = 7 e registrar 40 aulas com 0 faltas.", "Consultar a situação."],
  "Situação APROVADO (média 7,0 ≥ 7,0).", "Situação EM_EXAME_FINAL.",
  "Causa: comparação 'media > 7' em services._situacao. Correção: trocada para 'media >= 7' (RN11).", 1),
("BUG002", "Frequência exatamente 75% reprova por falta", "CT017", "RN13 / RF06", "Alta", "Alta", R3, R3, 1,
  ["Matricular o aluno em QS101/2026.2.", "Lançar N1 = N2 = 10.", "Registrar 40 aulas com 10 faltas (75,0%).", "Consultar a situação."],
  "Situação APROVADO (frequência 75% é o mínimo aceito).", "Situação REPROVADO_POR_FALTA.",
  "Causa: comparação 'freq <= 75' em services._situacao. Correção: trocada para 'freq < 75' (RN13).", 1),
("BUG003", "Sistema aceita notas negativas", "CT013", "RN09 / RF04", "Média", "Média", R3, R3, 1,
  ["Matricular o aluno em QS101/2026.2.", "Chamar lancar_nota(..., 'N1', -1)."],
  "ValidacaoError: nota deve estar entre 0 e 10.", "Nota -1 gravada sem erro (também -0,1).",
  "Causa: validar_nota só verificava o limite superior. Correção: condição 'valor < 0 or valor > 10'.", 1),
("BUG004", "Matrícula aceita uma vaga além do limite (vaga N+1)", "CT009 (e CT022)", "RN05 / RF03", "Alta", "Alta", R2, R2, 1,
  ["Cadastrar QS101 com 2 vagas e 3 alunos.", "Matricular os alunos 1 e 2.", "Matricular o aluno 3."],
  "RegraNegocioError: não há vagas disponíveis.", "3ª matrícula aceita (3 alunos em 2 vagas).",
  "Causa: comparação 'ocupacao > vagas' em services.matricular. Correção: trocada para 'ocupacao >= vagas'.", 1),
("BUG005", "Pré-requisitos: basta cumprir um dos pré-requisitos para matricular", "CT010", "RN06 / RF03", "Alta", "Alta", R2, R2, 1,
  ["Cadastrar MAT101, PRG101 e ED201 (pré-requisitos MAT101 e PRG101).", "Aprovar o aluno apenas em MAT101.", "Matricular o aluno em ED201."],
  "RegraNegocioError: pré-requisitos não cumpridos.", "Matrícula em ED201 aceita.",
  "Causa: uso de any() sobre a lista de pré-requisitos em services.matricular. Correção: trocado por all().", 2),
("BUG006", "Coeficiente de Rendimento calculado por média simples (sem ponderar pela carga horária)", "CT025", "RN15 / RF08", "Média", "Média", R4, R4, 1,
  ["Aprovar o aluno em MAT101 (40 h, média 9,0).", "Concluir PRG101 (80 h, média final 6,0).", "Chamar coeficiente_rendimento."],
  "CR = (9×40 + 6×80)/120 = 7,0.", "CR = 7,5 (média simples das médias finais).",
  "Causa: coeficiente_rendimento somava as médias sem usar a carga horária. Correção: média ponderada por carga horária.", 2),
("BUG007", "Cadastro de aluno aceita CPF duplicado", "CT003", "RN02 / RF01", "Alta", "Alta", R1, R1, 1,
  ["Cadastrar aluno com CPF 529.982.247-25.", "Cadastrar outro aluno com o mesmo CPF (52998224725)."],
  "RegraNegocioError: CPF já cadastrado.", "Segundo aluno cadastrado com o mesmo CPF (nova matrícula 20260002).",
  "Causa: não havia verificação de unicidade em cadastrar_aluno. Correção: verificação do CPF já cadastrado.", 1),
("BUG008", "Requisito RF07 (trancamento de matrícula) não implementado", "CT021, CT022, CT023, CT028", "RF07", "Alta", "Alta", R4, R4, 1,
  ["Matricular o aluno em QS101/2026.2.", "Chamar trancar_matricula(...)."],
  "Matrícula passa a TRANCADA.", "NotImplementedError: RF07 - trancamento de matrícula ainda não implementado.",
  "Causa: requisito não implementado na v0.1.0. Correção: implementação de trancar_matricula na v0.2.0.", 1),
("BUG009", "Trancamento não libera a vaga da disciplina nem o limite semestral do aluno", "CT022", "RN16 / RN05 / RN08", "Alta", "Alta", R4, R4, 2,
  ["Cadastrar QS101 com 1 vaga e 2 alunos; matricular o aluno 1.", "Trancar a matrícula do aluno 1.", "Matricular o aluno 2."],
  "Matrícula do aluno 2 aceita (vaga liberada).", "RegraNegocioError: não há vagas disponíveis (e, no cenário do limite de 6, 'Limite de disciplinas atingido').",
  "Causa: _ocupacao e _ativas_no_semestre contavam matrículas trancadas. Correção: contar apenas matrículas com status CURSANDO. Defeito mascarado no ciclo 1 por BUG004 e BUG008; revelado no ciclo 2.", 2),
]

RESULTADO_RETESTE = {
 # (bug, ciclo): (descrição, status)
}

# ---------------------------------------------------------------- riscos
RISCOS = [
    ("Dados mantidos apenas em memória (perda ao encerrar o processo)", "Alto", "Alta", "Adotar persistência (SQLite/PostgreSQL) e criar testes de integração com o banco."),
    ("Ausência de autenticação e perfis (secretaria, professor, aluno)", "Alto", "Média", "Implementar controle de acesso e casos de teste de segurança."),
    ("Arredondamento das médias em 2 casas decimais pode divergir da regra institucional", "Médio", "Média", "Validar a regra de arredondamento com a coordenação e ampliar os casos de valor-limite."),
    ("Não há testes de desempenho nem de concorrência (matrículas simultâneas na última vaga)", "Médio", "Baixa", "Executar testes de carga e adotar controle de concorrência quando houver persistência."),
]
