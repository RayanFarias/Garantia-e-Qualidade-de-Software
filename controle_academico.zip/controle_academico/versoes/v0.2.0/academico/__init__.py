"""Sistema de Controle Acadêmico - projeto A3 de Garantia da Qualidade de Software."""
from .services import SistemaAcademico
from .exceptions import ErroAcademico, ValidacaoError, RegraNegocioError, NaoEncontradoError

__all__ = [
    "SistemaAcademico",
    "ErroAcademico",
    "ValidacaoError",
    "RegraNegocioError",
    "NaoEncontradoError",
]
__version__ = "0.2.0"
