"""Regras de negócio do Sistema de Controle Acadêmico (armazenamento em memória)."""
from typing import Dict, List, Optional, Tuple

from . import regras as R
from .exceptions import NaoEncontradoError, RegraNegocioError, ValidacaoError
from .models import Aluno, Disciplina, Matricula
from .validators import (
    cpf_valido,
    email_valido,
    semestre_valido,
    somente_digitos,
    validar_inteiro_positivo,
    validar_nota,
)

AVALIACOES = ("N1", "N2", "FINAL")


class SistemaAcademico:
    """Fachada com todas as operações do sistema (RF01 a RF09)."""

    def __init__(self) -> None:
        self._alunos: Dict[str, Aluno] = {}
        self._disciplinas: Dict[str, Disciplina] = {}
        self._matriculas: List[Matricula] = []
        self._sequencia = 0

    # ------------------------------------------------------------------ RF01
    def cadastrar_aluno(self, nome: str, cpf: str, email: str) -> Aluno:
        nome = (nome or "").strip()
        if len(nome) < 3:
            raise ValidacaoError("Nome obrigatório (mínimo 3 caracteres).")
        if not cpf_valido(cpf):
            raise ValidacaoError("CPF inválido.")
        cpf_limpo = somente_digitos(cpf)
        if not email_valido(email):
            raise ValidacaoError("E-mail inválido.")
        self._sequencia += 1
        aluno = Aluno(f"{R.ANO_INGRESSO}{self._sequencia:04d}", nome, cpf_limpo, email.strip())
        self._alunos[aluno.matricula] = aluno
        return aluno

    def obter_aluno(self, matricula: str) -> Aluno:
        try:
            return self._alunos[matricula]
        except KeyError:
            raise NaoEncontradoError(f"Aluno {matricula} não encontrado.") from None

    # ------------------------------------------------------------------ RF02
    def cadastrar_disciplina(
        self, codigo: str, nome: str, carga_horaria: int, vagas: int, pre_requisitos=()
    ) -> Disciplina:
        codigo = (codigo or "").strip().upper()
        if not codigo or not (nome or "").strip():
            raise ValidacaoError("Código e nome da disciplina são obrigatórios.")
        if codigo in self._disciplinas:
            raise RegraNegocioError("Código de disciplina já cadastrado.")
        carga_horaria = validar_inteiro_positivo(carga_horaria, "Carga horária")
        vagas = validar_inteiro_positivo(vagas, "Vagas")
        prereqs = tuple(p.strip().upper() for p in pre_requisitos)
        for p in prereqs:
            if p not in self._disciplinas:
                raise NaoEncontradoError(f"Pré-requisito {p} não cadastrado.")
        disc = Disciplina(codigo, nome.strip(), carga_horaria, vagas, prereqs)
        self._disciplinas[codigo] = disc
        return disc

    def obter_disciplina(self, codigo: str) -> Disciplina:
        try:
            return self._disciplinas[(codigo or "").strip().upper()]
        except KeyError:
            raise NaoEncontradoError(f"Disciplina {codigo} não encontrada.") from None

    # ------------------------------------------------------------------ RF03
    def matricular(self, matricula_aluno: str, codigo: str, semestre: str) -> Matricula:
        aluno = self.obter_aluno(matricula_aluno)
        disc = self.obter_disciplina(codigo)
        if not semestre_valido(semestre):
            raise ValidacaoError("Semestre deve estar no formato AAAA.S (ex.: 2026.2).")

        for m in self._matriculas:
            if m.aluno == aluno.matricula and m.codigo == disc.codigo:
                if m.status == R.STATUS_CURSANDO and m.semestre == semestre:
                    raise RegraNegocioError("Aluno já matriculado nesta disciplina no semestre.")
                if self.situacao(m.aluno, m.codigo, m.semestre) == R.SIT_APROVADO:
                    raise RegraNegocioError("Aluno já foi aprovado nesta disciplina.")

        if disc.pre_requisitos and not any(self.aprovado_em(aluno.matricula, p) for p in disc.pre_requisitos):
            raise RegraNegocioError("Pré-requisitos não cumpridos.")

        if self._ocupacao(disc.codigo, semestre) > disc.vagas:
            raise RegraNegocioError("Não há vagas disponíveis na disciplina.")

        if self._ativas_no_semestre(aluno.matricula, semestre) >= R.MAX_DISCIPLINAS_SEMESTRE:
            raise RegraNegocioError("Limite de disciplinas por semestre atingido.")

        matricula = Matricula(aluno.matricula, disc.codigo, semestre)
        self._matriculas.append(matricula)
        return matricula

    def _ocupacao(self, codigo: str, semestre: str) -> int:
        return sum(
            1
            for m in self._matriculas
            if m.codigo == codigo and m.semestre == semestre
        )

    def _ativas_no_semestre(self, matricula_aluno: str, semestre: str) -> int:
        return sum(
            1
            for m in self._matriculas
            if m.aluno == matricula_aluno
            and m.semestre == semestre
        )

    def obter_matricula(self, matricula_aluno: str, codigo: str, semestre: str) -> Matricula:
        codigo = (codigo or "").strip().upper()
        for m in reversed(self._matriculas):  # a mais recente (após trancamento/rematrícula)
            if m.aluno == matricula_aluno and m.codigo == codigo and m.semestre == semestre:
                return m
        raise NaoEncontradoError("Matrícula do aluno na disciplina/semestre não encontrada.")

    def aprovado_em(self, matricula_aluno: str, codigo: str) -> bool:
        return any(
            m.aluno == matricula_aluno
            and m.codigo == codigo
            and self.situacao(m.aluno, m.codigo, m.semestre) == R.SIT_APROVADO
            for m in self._matriculas
        )

    # ------------------------------------------------------------ RF04 / RF05
    def lancar_nota(
        self, matricula_aluno: str, codigo: str, semestre: str, avaliacao: str, valor
    ) -> None:
        m = self.obter_matricula(matricula_aluno, codigo, semestre)
        if m.status == R.STATUS_TRANCADA:
            raise RegraNegocioError("Matrícula trancada não aceita lançamentos.")
        avaliacao = (avaliacao or "").upper()
        if avaliacao not in AVALIACOES:
            raise ValidacaoError("Avaliação deve ser N1, N2 ou FINAL.")
        nota = validar_nota(valor)
        if avaliacao == "FINAL":
            if self.situacao(matricula_aluno, codigo, semestre) != R.SIT_EM_EXAME_FINAL:
                raise RegraNegocioError("Aluno não está em exame final.")
            m.final = nota
        elif avaliacao == "N1":
            m.n1 = nota
        else:
            m.n2 = nota

    def registrar_frequencia(
        self, matricula_aluno: str, codigo: str, semestre: str, aulas_dadas: int, faltas: int
    ) -> None:
        m = self.obter_matricula(matricula_aluno, codigo, semestre)
        if m.status == R.STATUS_TRANCADA:
            raise RegraNegocioError("Matrícula trancada não aceita lançamentos.")
        aulas_dadas = validar_inteiro_positivo(aulas_dadas, "Aulas dadas")
        if isinstance(faltas, bool) or not isinstance(faltas, int) or not 0 <= faltas <= aulas_dadas:
            raise ValidacaoError("Faltas deve ser inteiro entre 0 e o total de aulas dadas.")
        m.aulas_dadas = aulas_dadas
        m.faltas = faltas

    # ------------------------------------------------------------------ RF06
    def frequencia(self, matricula_aluno: str, codigo: str, semestre: str) -> Optional[float]:
        m = self.obter_matricula(matricula_aluno, codigo, semestre)
        return self._frequencia(m)

    @staticmethod
    def _frequencia(m: Matricula) -> Optional[float]:
        if m.aulas_dadas <= 0:
            return None
        return round((m.aulas_dadas - m.faltas) / m.aulas_dadas * 100, 2)

    @staticmethod
    def _media_parcial(m: Matricula) -> Optional[float]:
        if m.n1 is None or m.n2 is None:
            return None
        return round((m.n1 + m.n2) / 2, 2)

    def media_parcial(self, matricula_aluno: str, codigo: str, semestre: str) -> Optional[float]:
        return self._media_parcial(self.obter_matricula(matricula_aluno, codigo, semestre))

    def _media_final(self, m: Matricula) -> Optional[float]:
        media = self._media_parcial(m)
        if media is None:
            return None
        if m.final is None:
            return media
        return round((media + m.final) / 2, 2)

    def media_final(self, matricula_aluno: str, codigo: str, semestre: str) -> Optional[float]:
        return self._media_final(self.obter_matricula(matricula_aluno, codigo, semestre))

    def situacao(self, matricula_aluno: str, codigo: str, semestre: str) -> str:
        m = self.obter_matricula(matricula_aluno, codigo, semestre)
        return self._situacao(m)

    def _situacao(self, m: Matricula) -> str:
        if m.status == R.STATUS_TRANCADA:
            return R.SIT_TRANCADA
        media = self._media_parcial(m)
        freq = self._frequencia(m)
        if media is None or freq is None:
            return R.SIT_EM_ANDAMENTO
        if freq <= R.FREQUENCIA_MINIMA:
            return R.SIT_REPROVADO_FALTA
        if media > R.MEDIA_APROVACAO:
            return R.SIT_APROVADO
        if media < R.MEDIA_MINIMA_EXAME:
            return R.SIT_REPROVADO_NOTA
        if m.final is None:
            return R.SIT_EM_EXAME_FINAL
        if self._media_final(m) >= R.MEDIA_FINAL_APROVACAO:
            return R.SIT_APROVADO
        return R.SIT_REPROVADO_NOTA

    # ------------------------------------------------------------------ RF07
    def trancar_matricula(self, matricula_aluno: str, codigo: str, semestre: str) -> Matricula:
        raise NotImplementedError("RF07 - trancamento de matrícula ainda não implementado")

    # ------------------------------------------------------------------ RF08
    def historico(self, matricula_aluno: str) -> List[dict]:
        self.obter_aluno(matricula_aluno)
        linhas = []
        for m in self._matriculas:
            if m.aluno != matricula_aluno:
                continue
            disc = self._disciplinas[m.codigo]
            linhas.append(
                {
                    "semestre": m.semestre,
                    "codigo": m.codigo,
                    "disciplina": disc.nome,
                    "carga_horaria": disc.carga_horaria,
                    "media_final": self._media_final(m),
                    "frequencia": self._frequencia(m),
                    "situacao": self._situacao(m),
                }
            )
        return sorted(linhas, key=lambda x: (x["semestre"], x["codigo"]))

    def coeficiente_rendimento(self, matricula_aluno: str) -> float:
        """CR = média das médias finais ponderada pela carga horária (RN15)."""
        concluidas: List[Tuple[float, int]] = [
            (l["media_final"], l["carga_horaria"])
            for l in self.historico(matricula_aluno)
            if l["situacao"] in R.SITUACOES_FINAIS
        ]
        if not concluidas:
            return 0.0
        return round(sum(media for media, _ in concluidas) / len(concluidas), 2)

    # ------------------------------------------------------------------ RF09
    def relatorio_disciplina(self, codigo: str, semestre: str) -> dict:
        disc = self.obter_disciplina(codigo)
        alunos = []
        for m in self._matriculas:
            if m.codigo != disc.codigo or m.semestre != semestre or m.status == R.STATUS_TRANCADA:
                continue
            alunos.append(
                {
                    "matricula": m.aluno,
                    "nome": self._alunos[m.aluno].nome,
                    "media_final": self._media_final(m),
                    "frequencia": self._frequencia(m),
                    "situacao": self._situacao(m),
                }
            )
        medias = [a["media_final"] for a in alunos if a["media_final"] is not None]
        concluidos = [a for a in alunos if a["situacao"] in R.SITUACOES_FINAIS]
        aprovados = [a for a in concluidos if a["situacao"] == R.SIT_APROVADO]
        return {
            "codigo": disc.codigo,
            "disciplina": disc.nome,
            "semestre": semestre,
            "total_alunos": len(alunos),
            "alunos": sorted(alunos, key=lambda a: a["nome"]),
            "media_turma": round(sum(medias) / len(medias), 2) if medias else None,
            "aprovados": len(aprovados),
            "taxa_aprovacao": round(len(aprovados) / len(concluidos) * 100, 2) if concluidos else 0.0,
        }
