# Sistema de Controle Acadêmico — Trabalho A3 (Garantia da Qualidade de Software)

Sistema em Python (armazenamento em memória) criado para ser testado com **pytest**, com documentação
de testes no modelo do professor (`docs/Especificacao_Testes_Controle_Academico.docx`).

## Estrutura
| Pasta / arquivo | Conteúdo |
|---|---|
| `src/academico/` | Versão final **v1.0.0** (todos os defeitos corrigidos) |
| `versoes/v0.1.0/`, `versoes/v0.2.0/` | Versões intermediárias com defeitos (usadas nos ciclos 1 e 2) |
| `tests/` | 28 casos de teste (CT001–CT028), 83 execuções pytest |
| `evidencias/` | Logs do pytest, XML JUnit de cada ciclo e *patches* das correções |
| `docs/` | Documento de especificação de testes (template do professor preenchido) |
| `scripts/` | `rodar_ciclo.sh` (executa um ciclo) e `gerar_especificacao_docx.py` (gera o DOCX) |
| `main.py` | Demonstração em linha de comando |

## Como executar
```bash
pip install -r requirements.txt
python3 -m pytest                          # versão final: 83 passed
scripts/rodar_ciclo.sh ciclo1 v0.1.0       # reproduz o ciclo 1 (17 falhas)
scripts/rodar_ciclo.sh ciclo2 v0.2.0       # reproduz o ciclo 2 (4 falhas)
scripts/rodar_ciclo.sh ciclo3 atual        # ciclo 3 (0 falhas)
python3 main.py                            # demonstração
```

## Ciclos de teste
| Ciclo | Versão | CTs aprovados | Execuções pytest | Defeitos |
|---|---|---|---|---|
| 1 | v0.1.0 | 16/28 | 66 ok / 17 falhas | BUG001–BUG008 detectados |
| 2 | v0.2.0 | 25/28 | 79 ok / 4 falhas | BUG001–004, 007, 008 corrigidos; BUG005, BUG006 abertos; BUG009 revelado |
| 3 | v1.0.0 | 28/28 | 83 ok / 0 falhas | BUG005, BUG006, BUG009 corrigidos |

## Defeitos (BUG) introduzidos e detectados
| Código | Defeito | CT que detecta |
|---|---|---|
| BUG001 | Média 7,0 não aprova diretamente | CT016 |
| BUG002 | Frequência 75% reprova por falta | CT017 |
| BUG003 | Nota negativa aceita | CT013 |
| BUG004 | Matrícula aceita vaga N+1 | CT009 |
| BUG005 | Basta 1 de N pré-requisitos | CT010 |
| BUG006 | CR por média simples (sem ponderar por carga horária) | CT025 |
| BUG007 | CPF duplicado aceito | CT003 |
| BUG008 | Trancamento (RF07) não implementado | CT021 |
| BUG009 | Trancamento não libera vaga/limite semestral | CT022 |

## Mapeamento com as etapas do barema
1. **Especificação de testes (10 pts)** — `docs/*.docx`, seções 1–12 (28 casos, ≥ 15 exigidos).
2. **Implementação (10 pts)** — `tests/` (28 casos, ≥ 10 exigidos) e registro de execução (seção 13).
3. **Apresentação final (20 pts)** — resultados: seções 12, 13, 15 e 16 do documento + `evidencias/`.

> Para o documento: substituir `[Integrante 1..4]` pelos nomes da equipe e preencher as assinaturas.
